var annotated_dup =
[
    [ "Bike", "d2/d3d/class_bike.html", "d2/d3d/class_bike" ],
    [ "Car", "d6/d44/class_car.html", "d6/d44/class_car" ],
    [ "DriveRecord", "d8/ddb/class_drive_record.html", "d8/ddb/class_drive_record" ],
    [ "Garage", "d2/d91/class_garage.html", "d2/d91/class_garage" ],
    [ "Object", "d8/d83/class_object.html", "d8/d83/class_object" ],
    [ "RecordEntry", "d2/de3/class_record_entry.html", "d2/de3/class_record_entry" ],
    [ "Truck", "db/d95/class_truck.html", "db/d95/class_truck" ],
    [ "Vehicle", "dd/df6/class_vehicle.html", "dd/df6/class_vehicle" ]
];