var class_garage =
[
    [ "Garage", "d2/d91/class_garage.html#a9c32438d0bb8f96de432f97dbb07dd80", null ],
    [ "Garage", "d2/d91/class_garage.html#a9018ef73a0ae3d3a4eb2d1d38193f7a0", null ],
    [ "~Garage", "d2/d91/class_garage.html#a6ca5d5442fc034da72120fe281c14db3", null ],
    [ "AddVehicle", "d2/d91/class_garage.html#a0099b296564271908b0f9ba661e309b4", null ],
    [ "DeleteVehicle", "d2/d91/class_garage.html#a4c6da2898f17e892169bc6d1a1c52f85", null ],
    [ "GetTotalDrivenKilometers", "d2/d91/class_garage.html#aac65d9e50e4aaa9e4560bc11838394ff", null ],
    [ "operator=", "d2/d91/class_garage.html#af9eca3071daaaa24411cbe6e60f9f097", null ],
    [ "Print", "d2/d91/class_garage.html#a27a4c36caa8096c44ebe5672fc46239d", null ],
    [ "SearchPlate", "d2/d91/class_garage.html#a3248bd1694728ed3fbbe22dad39af42a", null ],
    [ "m_vehicles", "d2/d91/class_garage.html#a731ec598aa3130fdb241d1f47b55c41f", null ]
];