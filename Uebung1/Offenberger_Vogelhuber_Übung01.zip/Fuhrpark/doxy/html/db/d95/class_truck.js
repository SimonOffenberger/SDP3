var class_truck =
[
    [ "Truck", "db/d95/class_truck.html#a02eba85dd130f6eac9810197218c69ed", null ],
    [ "Clone", "db/d95/class_truck.html#adb5ec1ff05a5c99c4c97ebce279b7c55", null ],
    [ "Print", "db/d95/class_truck.html#a8b6f0c959b0f17b089f26878b7ce0eab", null ]
];