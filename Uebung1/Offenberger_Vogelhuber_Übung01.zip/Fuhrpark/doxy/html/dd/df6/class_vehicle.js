var class_vehicle =
[
    [ "Vehicle", "dd/df6/class_vehicle.html#a1eff69903d28abcce12da2e460b33ed8", null ],
    [ "AddRecord", "dd/df6/class_vehicle.html#a563fc693b1226af46b4b27b3399e9dea", null ],
    [ "Clone", "dd/df6/class_vehicle.html#a20e46a56c0765ca79a6f566c96b9bb54", null ],
    [ "GetBrand", "dd/df6/class_vehicle.html#a9e11aa66f6220797b5e53c73bc46f846", null ],
    [ "GetDriveRecord", "dd/df6/class_vehicle.html#a2f5cc8f8ea69fcd45d7a45d798856e7c", null ],
    [ "GetFuelType", "dd/df6/class_vehicle.html#a2434ddb546ed209c418763181cbec658", null ],
    [ "GetMilage", "dd/df6/class_vehicle.html#ab1298438ed93b8d7f2078e005d7a7aa8", null ],
    [ "GetPlate", "dd/df6/class_vehicle.html#afaa9c43fb24e50e447989942eeb1e80e", null ],
    [ "Print", "dd/df6/class_vehicle.html#a5c7e74581e5b0e3fb0de7a41682264ef", null ],
    [ "m_brand", "dd/df6/class_vehicle.html#a8d228e16987acc6eb4f1848975aba851", null ],
    [ "m_fuel", "dd/df6/class_vehicle.html#aac5d63b0c4c8a7b30e70a04fc9b58e22", null ],
    [ "m_plate", "dd/df6/class_vehicle.html#ab6378767c820f1c0f918210df41bd91f", null ],
    [ "m_record", "dd/df6/class_vehicle.html#a38356829f7043221fccc913732943e20", null ]
];