var hierarchy =
[
    [ "Object", "d8/d83/class_object.html", [
      [ "DriveRecord", "d8/ddb/class_drive_record.html", null ],
      [ "Garage", "d2/d91/class_garage.html", null ],
      [ "RecordEntry", "d2/de3/class_record_entry.html", null ],
      [ "Vehicle", "dd/df6/class_vehicle.html", [
        [ "Bike", "d2/d3d/class_bike.html", null ],
        [ "Car", "d6/d44/class_car.html", null ],
        [ "Truck", "db/d95/class_truck.html", null ]
      ] ]
    ] ]
];