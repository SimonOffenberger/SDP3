var index =
[
    [ "Introduction", "index.html#intro_sec", null ],
    [ "Installation", "index.html#install_sec", [
      [ "Step 1: Opening the box", "index.html#step1", null ]
    ] ]
];