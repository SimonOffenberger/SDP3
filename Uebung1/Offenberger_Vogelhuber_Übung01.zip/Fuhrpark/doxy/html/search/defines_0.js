var searchData=
[
  ['color_5foutput_0',['COLOR_OUTPUT',['../d9/dfc/_test_8hpp.html#a11825a533f41a815d49681a121c7856d',1,'Test.hpp']]]
];
