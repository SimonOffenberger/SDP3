var searchData=
[
  ['white_0',['WHITE',['../d9/dfc/_test_8hpp.html#aa30c852df45f32d20b1037c79fb84184',1,'Test.hpp']]]
];
