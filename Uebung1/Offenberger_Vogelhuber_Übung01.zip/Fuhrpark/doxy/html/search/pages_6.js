var searchData=
[
  ['step_201_3a_20opening_20the_20box_0',['Step 1: Opening the box',['../index.html#step1',1,'']]]
];
