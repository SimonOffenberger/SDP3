/*****************************************************************//**
 * \file   ComissionWorker.cpp
 * \brief  ComissionWorker Class - inherits from Employee
 * \author Simon Vogelhuber
 * \date   October 2025
 *********************************************************************/
#include "ComissionWorker.hpp"

ComissionWorker::ComissionWorker(
    const std::string & name,
    const std::string & nameID,
    const TDate & dateJoined,
    const TDate & dateBirth,
    const std::string & socialSecurityNumber,
    const size_t & baseSalary,
    const size_t & commisionPerPiece,
    const size_t & piecesSold
) :
    Employee(name, nameID, dateJoined, dateBirth, socialSecurityNumber),
    m_baseSalary{ baseSalary },
    m_commisionPerPiece{ commisionPerPiece },
    m_piecesSold { piecesSold }
{}

std::ostream& ComissionWorker::DoPrintSpecificData(std::ostream & ost) const
{
    if (ost.bad())
    {
        throw Object::ERROR_BAD_OSTREAM;
        return ost;
    }
    ost << "Role: ComissionWorker" << std::endl;
    ost << "Base salary: " << m_baseSalary << " EUR" << std::endl;
    ost << "Comission per piece: " << m_commisionPerPiece << " EUR" << std::endl;
    ost << "Pieces sold: " << m_piecesSold << std::endl;

    return ost;
}

size_t ComissionWorker::GetSoldItems() const
{
    return m_piecesSold;
}

size_t ComissionWorker::GetSalary() const
{
    return m_baseSalary + m_piecesSold * m_commisionPerPiece;
}

TWorker ComissionWorker::GetWorkerType() const
{
    return E_CommisionWorker;
}

Employee* ComissionWorker::Clone() const
{
    return new ComissionWorker{ *this };
}
