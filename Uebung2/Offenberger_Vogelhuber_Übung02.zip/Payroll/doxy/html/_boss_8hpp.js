var _boss_8hpp =
[
    [ "Boss", "class_boss.html", "class_boss" ]
];