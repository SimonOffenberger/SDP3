var _client_8hpp =
[
    [ "Client", "class_client.html", "class_client" ]
];