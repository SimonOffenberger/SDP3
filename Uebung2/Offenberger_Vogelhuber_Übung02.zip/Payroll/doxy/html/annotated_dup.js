var annotated_dup =
[
    [ "Boss", "d3/d5e/class_boss.html", "d3/d5e/class_boss" ],
    [ "Client", "d3/d7a/class_client.html", "d3/d7a/class_client" ],
    [ "ComissionWorker", "da/d06/class_comission_worker.html", "da/d06/class_comission_worker" ],
    [ "Company", "d8/d41/class_company.html", "d8/d41/class_company" ],
    [ "Employee", "dc/d5c/class_employee.html", "dc/d5c/class_employee" ],
    [ "HourlyWorker", "dc/d24/class_hourly_worker.html", "dc/d24/class_hourly_worker" ],
    [ "IComp", "dc/dfc/class_i_comp.html", "dc/dfc/class_i_comp" ],
    [ "Object", "d8/d83/class_object.html", "d8/d83/class_object" ],
    [ "PieceWorker", "da/d76/class_piece_worker.html", "da/d76/class_piece_worker" ]
];