var annotated_dup =
[
    [ "Boss", "class_boss.html", "class_boss" ],
    [ "Client", "class_client.html", "class_client" ],
    [ "ComissionWorker", "class_comission_worker.html", "class_comission_worker" ],
    [ "Company", "class_company.html", "class_company" ],
    [ "Employee", "class_employee.html", "class_employee" ],
    [ "HourlyWorker", "class_hourly_worker.html", "class_hourly_worker" ],
    [ "IComp", "class_i_comp.html", "class_i_comp" ],
    [ "Object", "class_object.html", "class_object" ],
    [ "PieceWorker", "class_piece_worker.html", "class_piece_worker" ]
];