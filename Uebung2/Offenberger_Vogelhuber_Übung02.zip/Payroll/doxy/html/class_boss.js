var class_boss =
[
    [ "Clone", "class_boss.html#a68c1ae76fbab684707ffda966e6d93b9", null ],
    [ "GetProducedItems", "class_boss.html#af3217c9c3a87e7be9f69360435e6caf3", null ],
    [ "GetSalary", "class_boss.html#a4ed90ac03b4db755b314e39ef30f4c92", null ],
    [ "GetSoldItems", "class_boss.html#a9218915c1a4d535f51b0468d48066042", null ],
    [ "GetWorkerType", "class_boss.html#a828f152b29ea440e5a295804afcabeca", null ]
];