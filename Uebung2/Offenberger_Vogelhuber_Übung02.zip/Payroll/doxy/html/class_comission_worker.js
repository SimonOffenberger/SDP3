var class_comission_worker =
[
    [ "Clone", "class_comission_worker.html#a3da419b35eee9918b587ffb2c5422952", null ],
    [ "GetProducedItems", "class_comission_worker.html#a80973417f748e3079b899c967cf196a1", null ],
    [ "GetSalary", "class_comission_worker.html#a6a062ee1fd6ec02899eb63e83c165777", null ],
    [ "GetSoldItems", "class_comission_worker.html#a5500cf95c721b28cddc46dadaeba353f", null ],
    [ "GetWorkerType", "class_comission_worker.html#a45e6100397043aedb6a0e08b74222709", null ]
];