var class_company =
[
    [ "Company", "class_company.html#ade12868e72c49e6a0aced1c9a01b5e18", null ],
    [ "Company", "class_company.html#aa166f3820accc7a7f7d8f1b113e80b39", null ],
    [ "~Company", "class_company.html#a61c2a9ec178e683310583ef15635b53c", null ],
    [ "AddEmployee", "class_company.html#a13164cc7087be6a049c1506252b2dabc", null ],
    [ "FindWorkerByID", "class_company.html#ae87a8b534f18c066ba594a32b5037c53", null ],
    [ "GetCompanySize", "class_company.html#a1f6bee1441ae30fac21201c30b0b7400", null ],
    [ "GetCountWorkerBeforDate", "class_company.html#a38dfc13a084bdbde7565b8120b71c08f", null ],
    [ "GetLongestServing", "class_company.html#a70c7db2a6d20b6570d9b856e83d902ab", null ],
    [ "GetProducedItems", "class_company.html#a02da812ddca486cd9eaeae16f43bdc1e", null ],
    [ "GetSoldItems", "class_company.html#a7464a8c87da2a68cd32a3f668e8c976d", null ],
    [ "GetWorkerCount", "class_company.html#a127b4e4424dd49610554ed83960b38fc", null ],
    [ "operator=", "class_company.html#ab9657749dbdde6a9abd8f8ac1141f96b", null ],
    [ "PrintDataSheet", "class_company.html#a89bd7c5866b90c96c76e9bdf9e44f508", null ]
];