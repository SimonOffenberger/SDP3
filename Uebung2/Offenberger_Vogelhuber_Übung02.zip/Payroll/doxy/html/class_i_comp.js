var class_i_comp =
[
    [ "~IComp", "class_i_comp.html#ad5e8a537e781bb042c3e78eda2fe9b1b", null ],
    [ "AddEmployee", "class_i_comp.html#a19e15f4fc49983755b86dd86f4972edb", null ],
    [ "FindWorkerByID", "class_i_comp.html#a2740bb82218c82d8a501ba7cc881aa08", null ],
    [ "GetCompanySize", "class_i_comp.html#acfc745cf0d387d4d06aa420c04e76dd1", null ],
    [ "GetCountWorkerBeforDate", "class_i_comp.html#aa9183ef8122d83e4df611c7728706413", null ],
    [ "GetLongestServing", "class_i_comp.html#a3732d0b8e400d23096ec1cd1cec1b09a", null ],
    [ "GetProducedItems", "class_i_comp.html#a61ed27ebeecfa02651146fd4eebc8f41", null ],
    [ "GetSoldItems", "class_i_comp.html#a1c1f04f8eaa4b308497a1c33ec7bba53", null ],
    [ "GetWorkerCount", "class_i_comp.html#a2632bc4451ade44f55635dcd092eaf6f", null ],
    [ "PrintDataSheet", "class_i_comp.html#a3de8e8ec28032bdbe8f554e0ca4ad6c8", null ]
];