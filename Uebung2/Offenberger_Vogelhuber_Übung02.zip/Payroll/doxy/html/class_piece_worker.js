var class_piece_worker =
[
    [ "Clone", "class_piece_worker.html#a187cc512e89494be1f6a6672867f86fe", null ],
    [ "GetProducedItems", "class_piece_worker.html#adf119d3070be74a8cfa89d2e624d83b0", null ],
    [ "GetSalary", "class_piece_worker.html#aa5097ac0d56e1732a02a4301ba07e34a", null ],
    [ "GetSoldItems", "class_piece_worker.html#abab1b468745f1ddba8ac9e4ece2d7daf", null ],
    [ "GetWorkerType", "class_piece_worker.html#ac6568c47e29a826203f762683a9e9c1e", null ]
];