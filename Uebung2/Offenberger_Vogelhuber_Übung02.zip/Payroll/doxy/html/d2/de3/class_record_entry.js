var class_record_entry =
[
    [ "RecordEntry", "d2/de3/class_record_entry.html#a6621d88ec82b641c2ba097f026f8b6fd", null ],
    [ "GetDate", "d2/de3/class_record_entry.html#a38eeb0bb872429e92437af0f919de9cc", null ],
    [ "GetDistance", "d2/de3/class_record_entry.html#adf783500915555d2fca10f062c80c984", null ],
    [ "operator<", "d2/de3/class_record_entry.html#af1471375678f8a8703fa6997b4f7bfb0", null ],
    [ "Print", "d2/de3/class_record_entry.html#ad6d31b52d34fc83d9212de630bdb5ef3", null ],
    [ "m_date", "d2/de3/class_record_entry.html#aeb95f7b23126710c18faea64ff4b51f1", null ],
    [ "m_distance", "d2/de3/class_record_entry.html#a2359ed560a6355172754740d77a54128", null ]
];