var class_boss =
[
    [ "Boss", "d3/d5e/class_boss.html#af6ed7879358dc1af58a41bc3147e4ef2", null ],
    [ "Clone", "d3/d5e/class_boss.html#a68c1ae76fbab684707ffda966e6d93b9", null ],
    [ "DoPrintSpecificData", "d3/d5e/class_boss.html#a7138b3d6b8c7633e140feedb792eec6c", null ],
    [ "GetProducedItems", "d3/d5e/class_boss.html#af3217c9c3a87e7be9f69360435e6caf3", null ],
    [ "GetSalary", "d3/d5e/class_boss.html#a4ed90ac03b4db755b314e39ef30f4c92", null ],
    [ "GetSoldItems", "d3/d5e/class_boss.html#a9218915c1a4d535f51b0468d48066042", null ],
    [ "GetWorkerType", "d3/d5e/class_boss.html#a828f152b29ea440e5a295804afcabeca", null ],
    [ "m_salary", "d3/d5e/class_boss.html#a0db6e277e6a3f20bef27590931c234f3", null ]
];