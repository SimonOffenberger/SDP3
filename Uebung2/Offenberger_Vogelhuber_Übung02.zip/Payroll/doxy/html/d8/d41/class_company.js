var class_company =
[
    [ "Company", "d8/d41/class_company.html#ade12868e72c49e6a0aced1c9a01b5e18", null ],
    [ "Company", "d8/d41/class_company.html#aa166f3820accc7a7f7d8f1b113e80b39", null ],
    [ "~Company", "d8/d41/class_company.html#a61c2a9ec178e683310583ef15635b53c", null ],
    [ "AddEmployee", "d8/d41/class_company.html#a13164cc7087be6a049c1506252b2dabc", null ],
    [ "FindWorkerByID", "d8/d41/class_company.html#ae87a8b534f18c066ba594a32b5037c53", null ],
    [ "GetCompanySize", "d8/d41/class_company.html#a1f6bee1441ae30fac21201c30b0b7400", null ],
    [ "GetCountWorkerBeforDate", "d8/d41/class_company.html#a38dfc13a084bdbde7565b8120b71c08f", null ],
    [ "GetLongestServing", "d8/d41/class_company.html#a70c7db2a6d20b6570d9b856e83d902ab", null ],
    [ "GetProducedItems", "d8/d41/class_company.html#a02da812ddca486cd9eaeae16f43bdc1e", null ],
    [ "GetSoldItems", "d8/d41/class_company.html#a7464a8c87da2a68cd32a3f668e8c976d", null ],
    [ "GetWorkerCount", "d8/d41/class_company.html#a127b4e4424dd49610554ed83960b38fc", null ],
    [ "operator=", "d8/d41/class_company.html#ab9657749dbdde6a9abd8f8ac1141f96b", null ],
    [ "PrintDataSheet", "d8/d41/class_company.html#a89bd7c5866b90c96c76e9bdf9e44f508", null ],
    [ "m_companyName", "d8/d41/class_company.html#a78de9a9e9bfc8e4e93fe94f2f8701815", null ],
    [ "m_Employees", "d8/d41/class_company.html#aad3fa7a40b67fc769c9f71bcee83dfab", null ]
];