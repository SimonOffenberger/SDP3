var class_object =
[
    [ "Object", "d8/d83/class_object.html#afe9eeddd7068a37f62d3276a2fb49864", null ],
    [ "~Object", "d8/d83/class_object.html#a226f2ae2af766b77d83c09a4d766b725", null ]
];