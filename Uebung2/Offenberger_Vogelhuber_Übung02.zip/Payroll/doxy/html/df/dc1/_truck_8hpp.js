var _truck_8hpp =
[
    [ "Truck", "db/d95/class_truck.html", "db/d95/class_truck" ]
];