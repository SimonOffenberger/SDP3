var files_dup =
[
    [ "Boss.cpp", "df/d75/_boss_8cpp.html", null ],
    [ "Boss.hpp", "dd/d90/_boss_8hpp.html", "dd/d90/_boss_8hpp" ],
    [ "Client.cpp", "d2/dcf/_client_8cpp.html", null ],
    [ "Client.hpp", "d9/dbb/_client_8hpp.html", "d9/dbb/_client_8hpp" ],
    [ "ComissionWorker.cpp", "dd/d9a/_comission_worker_8cpp.html", null ],
    [ "ComissionWorker.hpp", "d3/da4/_comission_worker_8hpp.html", "d3/da4/_comission_worker_8hpp" ],
    [ "Company.cpp", "de/db2/_company_8cpp.html", null ],
    [ "Company.hpp", "da/dab/_company_8hpp.html", "da/dab/_company_8hpp" ],
    [ "Employee.cpp", "de/de6/_employee_8cpp.html", null ],
    [ "Employee.hpp", "d3/dba/_employee_8hpp.html", "d3/dba/_employee_8hpp" ],
    [ "HourlyWorker.cpp", "df/da4/_hourly_worker_8cpp.html", null ],
    [ "HourlyWorker.hpp", "d8/d52/_hourly_worker_8hpp.html", "d8/d52/_hourly_worker_8hpp" ],
    [ "IComp.hpp", "dc/d60/_i_comp_8hpp.html", "dc/d60/_i_comp_8hpp" ],
    [ "main.cpp", "df/d0a/main_8cpp.html", "df/d0a/main_8cpp" ],
    [ "Object.hpp", "db/d78/_object_8hpp.html", "db/d78/_object_8hpp" ],
    [ "PieceWorker.cpp", "d1/dd8/_piece_worker_8cpp.html", null ],
    [ "PieceWorker.hpp", "db/d26/_piece_worker_8hpp.html", "db/d26/_piece_worker_8hpp" ],
    [ "Test.hpp", "d9/dfc/_test_8hpp.html", "d9/dfc/_test_8hpp" ],
    [ "TWorker.hpp", "da/da6/_t_worker_8hpp.html", "da/da6/_t_worker_8hpp" ]
];