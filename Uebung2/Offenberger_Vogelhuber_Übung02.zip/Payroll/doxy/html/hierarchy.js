var hierarchy =
[
    [ "Client", "class_client.html", null ],
    [ "IComp", "class_i_comp.html", [
      [ "Company", "class_company.html", null ]
    ] ],
    [ "Object", "class_object.html", [
      [ "Company", "class_company.html", null ],
      [ "Employee", "class_employee.html", [
        [ "Boss", "class_boss.html", null ],
        [ "ComissionWorker", "class_comission_worker.html", null ],
        [ "HourlyWorker", "class_hourly_worker.html", null ],
        [ "PieceWorker", "class_piece_worker.html", null ]
      ] ]
    ] ]
];