var hierarchy =
[
    [ "Client", "d3/d7a/class_client.html", null ],
    [ "IComp", "dc/dfc/class_i_comp.html", [
      [ "Company", "d8/d41/class_company.html", null ]
    ] ],
    [ "Object", "d8/d83/class_object.html", [
      [ "Company", "d8/d41/class_company.html", null ],
      [ "Employee", "dc/d5c/class_employee.html", [
        [ "Boss", "d3/d5e/class_boss.html", null ],
        [ "ComissionWorker", "da/d06/class_comission_worker.html", null ],
        [ "HourlyWorker", "dc/d24/class_hourly_worker.html", null ],
        [ "PieceWorker", "da/d76/class_piece_worker.html", null ]
      ] ]
    ] ]
];