var searchData=
[
  ['addemployee_0',['AddEmployee',['../d8/d41/class_company.html#a13164cc7087be6a049c1506252b2dabc',1,'Company::AddEmployee()'],['../dc/dfc/class_i_comp.html#a19e15f4fc49983755b86dd86f4972edb',1,'IComp::AddEmployee()']]]
];
