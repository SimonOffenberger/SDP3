var searchData=
[
  ['boss_0',['Boss',['../class_boss.html',1,'']]],
  ['boss_2ecpp_1',['Boss.cpp',['../_boss_8cpp.html',1,'']]],
  ['boss_2ehpp_2',['Boss.hpp',['../_boss_8hpp.html',1,'']]]
];
