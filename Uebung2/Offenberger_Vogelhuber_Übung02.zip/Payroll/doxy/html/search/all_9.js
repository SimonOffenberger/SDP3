var searchData=
[
  ['object_0',['Object',['../class_object.html',1,'Object'],['../class_object.html#afe9eeddd7068a37f62d3276a2fb49864',1,'Object::Object()']]],
  ['object_2ehpp_1',['Object.hpp',['../_object_8hpp.html',1,'']]],
  ['operator_3d_2',['operator=',['../class_company.html#ab9657749dbdde6a9abd8f8ac1141f96b',1,'Company']]]
];
