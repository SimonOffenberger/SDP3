var searchData=
[
  ['boss_0',['Boss',['../d3/d5e/class_boss.html',1,'']]]
];
