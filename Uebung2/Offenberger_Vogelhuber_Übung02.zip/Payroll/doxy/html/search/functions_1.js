var searchData=
[
  ['boss_0',['Boss',['../d3/d5e/class_boss.html#af6ed7879358dc1af58a41bc3147e4ef2',1,'Boss']]]
];
