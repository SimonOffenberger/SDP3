var searchData=
[
  ['object_0',['Object',['../class_object.html#afe9eeddd7068a37f62d3276a2fb49864',1,'Object']]],
  ['operator_3d_1',['operator=',['../class_company.html#ab9657749dbdde6a9abd8f8ac1141f96b',1,'Company']]]
];
