var searchData=
[
  ['testcompanyassignop_0',['TestCompanyAssignOp',['../class_client.html#ad555b38cc7db33e1891a23bc9a1da4e3',1,'Client']]],
  ['testcompanycopyctor_1',['TestCompanyCopyCTOR',['../class_client.html#a935a125e6a51f5ae2fa8b105fa30cb12',1,'Client']]],
  ['testcompanygetter_2',['TestCompanyGetter',['../class_client.html#a0a85dbdf62e25ab6abe804f77ba26f5f',1,'Client']]],
  ['testcompanyprint_3',['TestCompanyPrint',['../class_client.html#a8add6c8db92d0980b5eb70eb6048cad6',1,'Client']]],
  ['testemptycompanygetter_4',['TestEmptyCompanyGetter',['../class_client.html#a198d864f3c8758e5b195dbaa4f61554c',1,'Client']]]
];
