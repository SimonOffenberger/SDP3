var searchData=
[
  ['error_5fbad_5fostream_0',['ERROR_BAD_OSTREAM',['../class_client.html#a7f7c3ca53f46f1fe6f3dc7611fbb4c4b',1,'Client::ERROR_BAD_OSTREAM'],['../class_object.html#a57c0b8c70b9dc9f1d1688b989cd08c04',1,'Object::ERROR_BAD_OSTREAM']]],
  ['error_5fduplicate_5fempl_1',['ERROR_DUPLICATE_EMPL',['../class_company.html#aae509d450d928dbb260550143e8ee4cd',1,'Company']]],
  ['error_5ffail_5fwrite_2',['ERROR_FAIL_WRITE',['../class_client.html#a91e442c938e2546b7617db06a925658c',1,'Client::ERROR_FAIL_WRITE'],['../class_object.html#a2adb788f2ffb1c6d56e8ec8b9789b0ac',1,'Object::ERROR_FAIL_WRITE']]],
  ['error_5fnullptr_3',['ERROR_NULLPTR',['../class_object.html#af34301090d8c55aa72e5cb22d8b4e9f5',1,'Object']]]
];
