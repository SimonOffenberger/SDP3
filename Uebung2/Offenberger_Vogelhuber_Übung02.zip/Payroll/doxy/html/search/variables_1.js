var searchData=
[
  ['error_5fbad_5fid_0',['ERROR_BAD_ID',['../dc/d5c/class_employee.html#a1255c80fa1176f89b0989a6b86f9e0d2',1,'Employee']]],
  ['error_5fbad_5fostream_1',['ERROR_BAD_OSTREAM',['../d3/d7a/class_client.html#a7f7c3ca53f46f1fe6f3dc7611fbb4c4b',1,'Client::ERROR_BAD_OSTREAM'],['../d8/d83/class_object.html#a57c0b8c70b9dc9f1d1688b989cd08c04',1,'Object::ERROR_BAD_OSTREAM']]],
  ['error_5fbad_5fsozial_5fsec_5fnum_2',['ERROR_BAD_SOZIAL_SEC_NUM',['../dc/d5c/class_employee.html#a7b5f94d486f0cbfe0e7419f99d52143d',1,'Employee']]],
  ['error_5fduplicate_5fempl_3',['ERROR_DUPLICATE_EMPL',['../d8/d41/class_company.html#aae509d450d928dbb260550143e8ee4cd',1,'Company']]],
  ['error_5ffail_5fwrite_4',['ERROR_FAIL_WRITE',['../d3/d7a/class_client.html#a91e442c938e2546b7617db06a925658c',1,'Client::ERROR_FAIL_WRITE'],['../d8/d83/class_object.html#a2adb788f2ffb1c6d56e8ec8b9789b0ac',1,'Object::ERROR_FAIL_WRITE']]],
  ['error_5fnullptr_5',['ERROR_NULLPTR',['../d8/d83/class_object.html#af34301090d8c55aa72e5cb22d8b4e9f5',1,'Object']]]
];
