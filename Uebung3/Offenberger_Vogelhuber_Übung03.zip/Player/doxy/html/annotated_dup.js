var annotated_dup =
[
    [ "Client", "d3/d7a/class_client.html", "d3/d7a/class_client" ],
    [ "IPlayer", "d5/d7a/class_i_player.html", "d5/d7a/class_i_player" ],
    [ "MusicPlayer", "dd/de1/class_music_player.html", "dd/de1/class_music_player" ],
    [ "MusicPlayerAdapter", "d1/dc7/class_music_player_adapter.html", "d1/dc7/class_music_player_adapter" ],
    [ "Object", "d8/d83/class_object.html", "d8/d83/class_object" ],
    [ "Song", "da/dc3/class_song.html", "da/dc3/class_song" ],
    [ "Video", "d2/d47/class_video.html", "d2/d47/class_video" ],
    [ "VideoPlayer", "d3/d7a/class_video_player.html", "d3/d7a/class_video_player" ],
    [ "VideoPlayerAdapter", "d6/dfa/class_video_player_adapter.html", "d6/dfa/class_video_player_adapter" ]
];