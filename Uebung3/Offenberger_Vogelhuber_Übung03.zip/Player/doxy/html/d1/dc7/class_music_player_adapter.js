var class_music_player_adapter =
[
    [ "MusicPlayerAdapter", "d1/dc7/class_music_player_adapter.html#a0b9649932520b40f3cb57822605b7031", null ],
    [ "MusicPlayerAdapter", "d1/dc7/class_music_player_adapter.html#a5088b91626cc5d09e3c1ee483af81eb7", null ],
    [ "Next", "d1/dc7/class_music_player_adapter.html#aa77334be7092d04025838f213ccaff6d", null ],
    [ "operator=", "d1/dc7/class_music_player_adapter.html#a9842c582694b11df1b634d432706e20f", null ],
    [ "Play", "d1/dc7/class_music_player_adapter.html#a39ce1c84623e342bc3db8e3fd7ba30c2", null ],
    [ "Prev", "d1/dc7/class_music_player_adapter.html#af57a0ca90bbb1e1bdac100d3b282dd0a", null ],
    [ "Select", "d1/dc7/class_music_player_adapter.html#a2ca43996369ecc7a9599a07531d0669b", null ],
    [ "Stop", "d1/dc7/class_music_player_adapter.html#ad636bde6144a6ee74aaf9b622f3d0e26", null ],
    [ "VollDec", "d1/dc7/class_music_player_adapter.html#ab4e50d46fae1f2777799463e4d54f918", null ],
    [ "VollInc", "d1/dc7/class_music_player_adapter.html#ae06c332b9dbb68b1144447495c090fee", null ],
    [ "m_player", "d1/dc7/class_music_player_adapter.html#a0b9daea00381389803f3fb2fec9dba77", null ]
];