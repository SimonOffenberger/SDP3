var class_video =
[
    [ "Video", "d2/d47/class_video.html#a945ebc0f110c54552b269ea0eadbec80", null ],
    [ "GetDuration", "d2/d47/class_video.html#ac5563431085d7c878a0dbfbe5fbd5a16", null ],
    [ "GetFormatID", "d2/d47/class_video.html#a7981631383a9992712b06a53ea35138a", null ],
    [ "GetTitle", "d2/d47/class_video.html#a60310a47620392cab167a685648865b5", null ],
    [ "m_duration", "d2/d47/class_video.html#aecd2e1ee7b7ef7493384b2cce414c2f3", null ],
    [ "m_format", "d2/d47/class_video.html#a8ea400101b2d6cc8be10d04a0ed9da8a", null ],
    [ "m_title", "d2/d47/class_video.html#a9b39ce43417fed1f3da42d8c28ed5b4e", null ]
];