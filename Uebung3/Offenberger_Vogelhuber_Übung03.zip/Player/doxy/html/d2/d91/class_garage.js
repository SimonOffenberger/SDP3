var class_garage =
[
    [ "Garage", "d2/d91/class_garage.html#a9c32438d0bb8f96de432f97dbb07dd80", null ],
    [ "Garage", "d2/d91/class_garage.html#a3a7f9239d8de7898e339b6d5ebb8d64a", null ],
    [ "~Garage", "d2/d91/class_garage.html#a6ca5d5442fc034da72120fe281c14db3", null ],
    [ "AddVehicle", "d2/d91/class_garage.html#a0099b296564271908b0f9ba661e309b4", null ],
    [ "DeleteVehicle", "d2/d91/class_garage.html#a4c6da2898f17e892169bc6d1a1c52f85", null ],
    [ "GetTotalDrivenKilometers", "d2/d91/class_garage.html#aac65d9e50e4aaa9e4560bc11838394ff", null ],
    [ "operator=", "d2/d91/class_garage.html#af9eca3071daaaa24411cbe6e60f9f097", null ],
    [ "Print", "d2/d91/class_garage.html#a86071f9ed6cd3ecccbc3c2c3dc56bce9", null ],
    [ "SearchPlate", "d2/d91/class_garage.html#a3248bd1694728ed3fbbe22dad39af42a", null ],
    [ "m_vehicles", "d2/d91/class_garage.html#a731ec598aa3130fdb241d1f47b55c41f", null ]
];