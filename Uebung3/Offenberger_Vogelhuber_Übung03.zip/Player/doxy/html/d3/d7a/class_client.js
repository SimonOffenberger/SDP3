var class_client =
[
    [ "Test_IPlayerEmptyPlay", "d3/d7a/class_client.html#a1b0575ba56de7804a21a33fd5d018d0a", null ],
    [ "Test_IPlayerPlay", "d3/d7a/class_client.html#a6f7c74ed428d1eb1ef0db9cfec18273a", null ],
    [ "Test_IPlayerVolumeCTRL", "d3/d7a/class_client.html#a5b4ae34588f0c5b7b38448005eb7a188", null ]
];