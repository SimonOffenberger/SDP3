var class_video_player =
[
    [ "VideoPlayer", "d3/d7a/class_video_player.html#a00262511eb06de0b83092285cae693df", null ],
    [ "VideoPlayer", "d3/d7a/class_video_player.html#aa4f9c496d3eb0d90fc77163ed931c64f", null ],
    [ "Add", "d3/d7a/class_video_player.html#a6be211f44478f220415dd408408bcf8a", null ],
    [ "CurIndex", "d3/d7a/class_video_player.html#a48fbc84bc65e973e927cd8beb578ef17", null ],
    [ "CurVideo", "d3/d7a/class_video_player.html#a23af7a0a33fb72988050e91a8ea31529", null ],
    [ "First", "d3/d7a/class_video_player.html#a6c35430d348d4134067dfb86e5fcddc4", null ],
    [ "GetVolume", "d3/d7a/class_video_player.html#af7a343871ec258028abf906f4c9a994d", null ],
    [ "Next", "d3/d7a/class_video_player.html#af27c8ff39bbb0214293ce3ecef13f29d", null ],
    [ "operator=", "d3/d7a/class_video_player.html#ab551049534379927373c8188bee3d3fa", null ],
    [ "Play", "d3/d7a/class_video_player.html#a18c39f0d65b9c3fc0f7943020126938e", null ],
    [ "SetVolume", "d3/d7a/class_video_player.html#afbc8dd4b9c80c68373163654341c1d1e", null ],
    [ "Stop", "d3/d7a/class_video_player.html#a84e1e66483126d070b127ca1e96be954", null ],
    [ "m_curIndex", "d3/d7a/class_video_player.html#aac9dc422314a6e42e12e39705a8ae17d", null ],
    [ "m_Videos", "d3/d7a/class_video_player.html#ad4c3cc18022c0a7fc3762d68a1450cca", null ],
    [ "m_volume", "d3/d7a/class_video_player.html#aa8153f648061bd1242460099e460e088", null ]
];