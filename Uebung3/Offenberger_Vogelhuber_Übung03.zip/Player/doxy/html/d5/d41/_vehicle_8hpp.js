var _vehicle_8hpp =
[
    [ "Vehicle", "dd/df6/class_vehicle.html", "dd/df6/class_vehicle" ],
    [ "TFuel", "d5/d41/_vehicle_8hpp.html#a4ba8f0fe0470c76ce7ee40db1ea59fbe", [
      [ "Diesel", "d5/d41/_vehicle_8hpp.html#a4ba8f0fe0470c76ce7ee40db1ea59fbeae116eac51cf6ae270db7ce4a977c72a1", null ],
      [ "Benzin", "d5/d41/_vehicle_8hpp.html#a4ba8f0fe0470c76ce7ee40db1ea59fbeaa3e89b2c1eb296e9ba5a8e1000ce0eea", null ],
      [ "Elektro", "d5/d41/_vehicle_8hpp.html#a4ba8f0fe0470c76ce7ee40db1ea59fbea42d4d8e97abf46da02fac3ec08898c55", null ]
    ] ]
];