var _music_player_adapter_8hpp =
[
    [ "MusicPlayerAdapter", "d1/dc7/class_music_player_adapter.html", "d1/dc7/class_music_player_adapter" ]
];