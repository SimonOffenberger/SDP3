var class_i_player =
[
    [ "~IPlayer", "d5/d7a/class_i_player.html#a51fad967141534e6267e19ff3a76bc69", null ],
    [ "Next", "d5/d7a/class_i_player.html#adc9447549aeee72d1bc6177492589788", null ],
    [ "Play", "d5/d7a/class_i_player.html#a36c38ad2a33c954ad2a8e353f505c6cf", null ],
    [ "Prev", "d5/d7a/class_i_player.html#a922454a3d77708974ed61115f58b859c", null ],
    [ "Select", "d5/d7a/class_i_player.html#a6c2c77a04b2a58e0affffb043eaa94f6", null ],
    [ "Stop", "d5/d7a/class_i_player.html#a1c074d0a20cd1fbcf6d459dc597bc0df", null ],
    [ "VollDec", "d5/d7a/class_i_player.html#a3464b3862e2fd97bdcd22aeb8a8bc463", null ],
    [ "VollInc", "d5/d7a/class_i_player.html#ade0462490905ceeab23f1b491911f49c", null ]
];