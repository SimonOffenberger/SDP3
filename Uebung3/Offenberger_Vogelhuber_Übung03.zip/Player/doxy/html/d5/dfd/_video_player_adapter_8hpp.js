var _video_player_adapter_8hpp =
[
    [ "VideoPlayerAdapter", "d6/dfa/class_video_player_adapter.html", "d6/dfa/class_video_player_adapter" ]
];