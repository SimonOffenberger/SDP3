var class_video_player_adapter =
[
    [ "VideoPlayerAdapter", "d6/dfa/class_video_player_adapter.html#a75ebf6260c88c062ba480d1b00fdfdcd", null ],
    [ "VideoPlayerAdapter", "d6/dfa/class_video_player_adapter.html#a008f2e0ef40a8c574360a3a864a302fe", null ],
    [ "Next", "d6/dfa/class_video_player_adapter.html#aa112f664c556e309397e77e9d107683c", null ],
    [ "operator=", "d6/dfa/class_video_player_adapter.html#ab16526f551a9d1b00756240341930365", null ],
    [ "Play", "d6/dfa/class_video_player_adapter.html#a457b82a1a41f5b12e23035e25929f9a1", null ],
    [ "Prev", "d6/dfa/class_video_player_adapter.html#ab3fc0027dd10ffa79c04a509e8206780", null ],
    [ "Select", "d6/dfa/class_video_player_adapter.html#a02240c1a026b327c7e37dd9858fb01af", null ],
    [ "Stop", "d6/dfa/class_video_player_adapter.html#ae2b58f697a2509047e86d03bbe785aee", null ],
    [ "VollDec", "d6/dfa/class_video_player_adapter.html#a0ce233a7038b946b59dad9323d529bbe", null ],
    [ "VollInc", "d6/dfa/class_video_player_adapter.html#ae4cf6c1f832af929d4088453017b55d6", null ],
    [ "m_player", "d6/dfa/class_video_player_adapter.html#a67733ff1012b9254eeab52de7499b4e7", null ]
];