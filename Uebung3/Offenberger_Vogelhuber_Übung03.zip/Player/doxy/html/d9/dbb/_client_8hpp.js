var _client_8hpp =
[
    [ "Client", "d3/d7a/class_client.html", "d3/d7a/class_client" ]
];