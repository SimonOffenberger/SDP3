var class_song =
[
    [ "Song", "da/dc3/class_song.html#aabb60297c8f55c7313445f173f73faf4", null ],
    [ "GetDuration", "da/dc3/class_song.html#a3d2f3efe741486ba9dd7f0ed24f491dc", null ],
    [ "GetTitle", "da/dc3/class_song.html#a34107250368de916d4037988b097658a", null ],
    [ "m_duration", "da/dc3/class_song.html#a4fed272352dee6bfbc0927e1f34c8fcc", null ],
    [ "m_name", "da/dc3/class_song.html#a4dd7fc1d05e40d4512c079c8f76651d7", null ]
];