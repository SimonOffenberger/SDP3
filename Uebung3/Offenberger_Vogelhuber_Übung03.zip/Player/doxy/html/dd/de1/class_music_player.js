var class_music_player =
[
    [ "MusicPlayer", "dd/de1/class_music_player.html#a55fc12bfe7188f72ebad977cbc731b16", null ],
    [ "MusicPlayer", "dd/de1/class_music_player.html#a70bd4bc80c4a79747b41528df8ef68c4", null ],
    [ "Add", "dd/de1/class_music_player.html#aed8cdbc7bd8f9bc25d15cb3f36a5a43f", null ],
    [ "DecreaseVol", "dd/de1/class_music_player.html#a1cc42e1740db17903cf93839d88f9713", null ],
    [ "Find", "dd/de1/class_music_player.html#a72916e3d4b89ce3765591f324f41c173", null ],
    [ "GetCount", "dd/de1/class_music_player.html#a9f1af67041e460e9f05da283d7df9202", null ],
    [ "GetCurIndex", "dd/de1/class_music_player.html#acb8265daab8ee1669b2d36d01a67a65a", null ],
    [ "IncreaseVol", "dd/de1/class_music_player.html#af92f42737365bbbe930b8490c11ac687", null ],
    [ "operator=", "dd/de1/class_music_player.html#af75b338bf7495c7e347b5a4130398e5d", null ],
    [ "Start", "dd/de1/class_music_player.html#a73e800c81fde41edcac80734844e6204", null ],
    [ "Stop", "dd/de1/class_music_player.html#a3f900f8b7035c59770d3f6fa9cd2173c", null ],
    [ "SwitchNext", "dd/de1/class_music_player.html#a70b76a99045ef74c70ff94c92923581f", null ],
    [ "m_currentSongIdx", "dd/de1/class_music_player.html#aed3047e0799e34d4f207803ae6373559", null ],
    [ "m_songs", "dd/de1/class_music_player.html#a119d15fa7ad0c43e73a30a3b2091b4f9", null ],
    [ "m_volume", "dd/de1/class_music_player.html#a8741c469dbb31a8df65b35a068b2116f", null ]
];