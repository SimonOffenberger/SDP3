var files_dup =
[
    [ "Client.cpp", "d2/dcf/_client_8cpp.html", null ],
    [ "Client.hpp", "d9/dbb/_client_8hpp.html", "d9/dbb/_client_8hpp" ],
    [ "EVideoFormat.hpp", "df/d67/_e_video_format_8hpp.html", "df/d67/_e_video_format_8hpp" ],
    [ "IPlayer.hpp", "d9/d1c/_i_player_8hpp.html", "d9/d1c/_i_player_8hpp" ],
    [ "main.cpp", "df/d0a/main_8cpp.html", "df/d0a/main_8cpp" ],
    [ "MusicPlayer.cpp", "dc/d7d/_music_player_8cpp.html", null ],
    [ "MusicPlayer.hpp", "de/de6/_music_player_8hpp.html", "de/de6/_music_player_8hpp" ],
    [ "MusicPlayerAdapter.cpp", "d4/d06/_music_player_adapter_8cpp.html", null ],
    [ "MusicPlayerAdapter.hpp", "d5/d61/_music_player_adapter_8hpp.html", "d5/d61/_music_player_adapter_8hpp" ],
    [ "Object.hpp", "db/d78/_object_8hpp.html", "db/d78/_object_8hpp" ],
    [ "Song.cpp", "dc/d60/_song_8cpp.html", null ],
    [ "Song.hpp", "df/d1f/_song_8hpp.html", "df/d1f/_song_8hpp" ],
    [ "Test.hpp", "d9/dfc/_test_8hpp.html", "d9/dfc/_test_8hpp" ],
    [ "Video.cpp", "d1/dad/_video_8cpp.html", null ],
    [ "Video.hpp", "d9/d22/_video_8hpp.html", "d9/d22/_video_8hpp" ],
    [ "VideoPlayer.cpp", "df/db2/_video_player_8cpp.html", null ],
    [ "VideoPlayer.hpp", "de/d57/_video_player_8hpp.html", "de/d57/_video_player_8hpp" ],
    [ "VideoPlayerAdapter.cpp", "da/da7/_video_player_adapter_8cpp.html", null ],
    [ "VideoPlayerAdapter.hpp", "d5/dfd/_video_player_adapter_8hpp.html", "d5/dfd/_video_player_adapter_8hpp" ]
];