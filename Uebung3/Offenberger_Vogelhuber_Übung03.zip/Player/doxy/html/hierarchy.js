var hierarchy =
[
    [ "IPlayer", "d5/d7a/class_i_player.html", [
      [ "MusicPlayerAdapter", "d1/dc7/class_music_player_adapter.html", null ],
      [ "VideoPlayerAdapter", "d6/dfa/class_video_player_adapter.html", null ]
    ] ],
    [ "Object", "d8/d83/class_object.html", [
      [ "Client", "d3/d7a/class_client.html", null ],
      [ "MusicPlayer", "dd/de1/class_music_player.html", null ],
      [ "MusicPlayerAdapter", "d1/dc7/class_music_player_adapter.html", null ],
      [ "Song", "da/dc3/class_song.html", null ],
      [ "Video", "d2/d47/class_video.html", null ],
      [ "VideoPlayer", "d3/d7a/class_video_player.html", null ],
      [ "VideoPlayerAdapter", "d6/dfa/class_video_player_adapter.html", null ]
    ] ]
];