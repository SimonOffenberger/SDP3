var searchData=
[
  ['decreasevol_0',['DecreaseVol',['../dd/de1/class_music_player.html#a1cc42e1740db17903cf93839d88f9713',1,'MusicPlayer']]],
  ['default_5fvolume_1',['DEFAULT_VOLUME',['../dd/de1/class_music_player.html#a6bdf40a5a0b5b89f8ce44835c8fdd1b3',1,'MusicPlayer::DEFAULT_VOLUME'],['../d3/d7a/class_video_player.html#a642a96d19cfcc8b35135dee47e195707',1,'VideoPlayer::DEFAULT_VOLUME']]]
];
