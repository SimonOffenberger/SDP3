var searchData=
[
  ['m_5fcurindex_0',['m_curIndex',['../d3/d7a/class_video_player.html#aac9dc422314a6e42e12e39705a8ae17d',1,'VideoPlayer']]],
  ['m_5fcurrentsongidx_1',['m_currentSongIdx',['../dd/de1/class_music_player.html#aed3047e0799e34d4f207803ae6373559',1,'MusicPlayer']]],
  ['m_5fduration_2',['m_duration',['../da/dc3/class_song.html#a4fed272352dee6bfbc0927e1f34c8fcc',1,'Song::m_duration'],['../d2/d47/class_video.html#aecd2e1ee7b7ef7493384b2cce414c2f3',1,'Video::m_duration']]],
  ['m_5fformat_3',['m_format',['../d2/d47/class_video.html#a8ea400101b2d6cc8be10d04a0ed9da8a',1,'Video']]],
  ['m_5fname_4',['m_name',['../da/dc3/class_song.html#a4dd7fc1d05e40d4512c079c8f76651d7',1,'Song']]],
  ['m_5fplayer_5',['m_player',['../d1/dc7/class_music_player_adapter.html#a0b9daea00381389803f3fb2fec9dba77',1,'MusicPlayerAdapter::m_player'],['../d6/dfa/class_video_player_adapter.html#a67733ff1012b9254eeab52de7499b4e7',1,'VideoPlayerAdapter::m_player']]],
  ['m_5fsongs_6',['m_songs',['../dd/de1/class_music_player.html#a119d15fa7ad0c43e73a30a3b2091b4f9',1,'MusicPlayer']]],
  ['m_5ftitle_7',['m_title',['../d2/d47/class_video.html#a9b39ce43417fed1f3da42d8c28ed5b4e',1,'Video']]],
  ['m_5fvideos_8',['m_Videos',['../d3/d7a/class_video_player.html#ad4c3cc18022c0a7fc3762d68a1450cca',1,'VideoPlayer']]],
  ['m_5fvolume_9',['m_volume',['../dd/de1/class_music_player.html#a8741c469dbb31a8df65b35a068b2116f',1,'MusicPlayer::m_volume'],['../d3/d7a/class_video_player.html#aa8153f648061bd1242460099e460e088',1,'VideoPlayer::m_volume']]],
  ['main_10',['main',['../df/d0a/main_8cpp.html#a840291bc02cba5474a4cb46a9b9566fe',1,'main.cpp']]],
  ['main_2ecpp_11',['main.cpp',['../df/d0a/main_8cpp.html',1,'']]],
  ['max_5fvolume_12',['MAX_VOLUME',['../dd/de1/class_music_player.html#a4a7b0482238a1137788f69ec5871891d',1,'MusicPlayer::MAX_VOLUME'],['../d3/d7a/class_video_player.html#ad08658b265b785891e7cb418d47df983',1,'VideoPlayer::MAX_VOLUME']]],
  ['min_5fvolume_13',['MIN_VOLUME',['../dd/de1/class_music_player.html#a9a3a4109af51f0d3781ba8d5b0609438',1,'MusicPlayer::MIN_VOLUME'],['../d3/d7a/class_video_player.html#a5fb4b012843cb7afa5a4b9c4ea6d764f',1,'VideoPlayer::MIN_VOLUME']]],
  ['mkv_14',['MKV',['../df/d67/_e_video_format_8hpp.html#a3fb3c293ba62f1c3bfa639d83dad5ca7abc5a0dfbf35ec22ac2c0f8c1e5534d8e',1,'EVideoFormat.hpp']]],
  ['musicplayer_15',['MusicPlayer',['../dd/de1/class_music_player.html',1,'MusicPlayer'],['../dd/de1/class_music_player.html#a55fc12bfe7188f72ebad977cbc731b16',1,'MusicPlayer::MusicPlayer()=default'],['../dd/de1/class_music_player.html#a70bd4bc80c4a79747b41528df8ef68c4',1,'MusicPlayer::MusicPlayer(MusicPlayer &amp;Music)=delete']]],
  ['musicplayer_2ecpp_16',['MusicPlayer.cpp',['../dc/d7d/_music_player_8cpp.html',1,'']]],
  ['musicplayer_2ehpp_17',['MusicPlayer.hpp',['../de/de6/_music_player_8hpp.html',1,'']]],
  ['musicplayeradapter_18',['MusicPlayerAdapter',['../d1/dc7/class_music_player_adapter.html',1,'MusicPlayerAdapter'],['../d1/dc7/class_music_player_adapter.html#a0b9649932520b40f3cb57822605b7031',1,'MusicPlayerAdapter::MusicPlayerAdapter(MusicPlayer &amp;player)'],['../d1/dc7/class_music_player_adapter.html#a5088b91626cc5d09e3c1ee483af81eb7',1,'MusicPlayerAdapter::MusicPlayerAdapter(MusicPlayerAdapter &amp;Music)=delete']]],
  ['musicplayeradapter_2ecpp_19',['MusicPlayerAdapter.cpp',['../d4/d06/_music_player_adapter_8cpp.html',1,'']]],
  ['musicplayeradapter_2ehpp_20',['MusicPlayerAdapter.hpp',['../d5/d61/_music_player_adapter_8hpp.html',1,'']]]
];
