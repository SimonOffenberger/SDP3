var searchData=
[
  ['next_0',['Next',['../d5/d7a/class_i_player.html#adc9447549aeee72d1bc6177492589788',1,'IPlayer::Next()'],['../d1/dc7/class_music_player_adapter.html#aa77334be7092d04025838f213ccaff6d',1,'MusicPlayerAdapter::Next()'],['../d3/d7a/class_video_player.html#af27c8ff39bbb0214293ce3ecef13f29d',1,'VideoPlayer::Next()'],['../d6/dfa/class_video_player_adapter.html#aa112f664c556e309397e77e9d107683c',1,'VideoPlayerAdapter::Next()']]]
];
