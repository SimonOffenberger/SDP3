var searchData=
[
  ['play_0',['Play',['../d5/d7a/class_i_player.html#a36c38ad2a33c954ad2a8e353f505c6cf',1,'IPlayer::Play()'],['../d1/dc7/class_music_player_adapter.html#a39ce1c84623e342bc3db8e3fd7ba30c2',1,'MusicPlayerAdapter::Play()'],['../d3/d7a/class_video_player.html#a18c39f0d65b9c3fc0f7943020126938e',1,'VideoPlayer::Play()'],['../d6/dfa/class_video_player_adapter.html#a457b82a1a41f5b12e23035e25929f9a1',1,'VideoPlayerAdapter::Play()']]],
  ['prev_1',['Prev',['../d5/d7a/class_i_player.html#a922454a3d77708974ed61115f58b859c',1,'IPlayer::Prev()'],['../d1/dc7/class_music_player_adapter.html#af57a0ca90bbb1e1bdac100d3b282dd0a',1,'MusicPlayerAdapter::Prev()'],['../d6/dfa/class_video_player_adapter.html#ab3fc0027dd10ffa79c04a509e8206780',1,'VideoPlayerAdapter::Prev()']]]
];
