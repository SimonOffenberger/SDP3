var searchData=
[
  ['red_0',['RED',['../d9/dfc/_test_8hpp.html#a5f0567db0c77643181763813d5fa4b8b',1,'Test.hpp']]]
];
