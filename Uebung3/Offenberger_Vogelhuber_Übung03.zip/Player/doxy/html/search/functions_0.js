var searchData=
[
  ['add_0',['Add',['../dd/de1/class_music_player.html#aed8cdbc7bd8f9bc25d15cb3f36a5a43f',1,'MusicPlayer::Add()'],['../d3/d7a/class_video_player.html#a6be211f44478f220415dd408408bcf8a',1,'VideoPlayer::Add()']]]
];
