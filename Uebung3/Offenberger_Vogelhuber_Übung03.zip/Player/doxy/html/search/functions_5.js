var searchData=
[
  ['increasevol_0',['IncreaseVol',['../dd/de1/class_music_player.html#af92f42737365bbbe930b8490c11ac687',1,'MusicPlayer']]]
];
