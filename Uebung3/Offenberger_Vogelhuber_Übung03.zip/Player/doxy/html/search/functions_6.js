var searchData=
[
  ['main_0',['main',['../df/d0a/main_8cpp.html#a840291bc02cba5474a4cb46a9b9566fe',1,'main.cpp']]],
  ['musicplayer_1',['MusicPlayer',['../dd/de1/class_music_player.html#a55fc12bfe7188f72ebad977cbc731b16',1,'MusicPlayer::MusicPlayer()=default'],['../dd/de1/class_music_player.html#a70bd4bc80c4a79747b41528df8ef68c4',1,'MusicPlayer::MusicPlayer(MusicPlayer &amp;Music)=delete']]],
  ['musicplayeradapter_2',['MusicPlayerAdapter',['../d1/dc7/class_music_player_adapter.html#a0b9649932520b40f3cb57822605b7031',1,'MusicPlayerAdapter::MusicPlayerAdapter(MusicPlayer &amp;player)'],['../d1/dc7/class_music_player_adapter.html#a5088b91626cc5d09e3c1ee483af81eb7',1,'MusicPlayerAdapter::MusicPlayerAdapter(MusicPlayerAdapter &amp;Music)=delete']]]
];
