var searchData=
[
  ['video_0',['Video',['../d2/d47/class_video.html#a945ebc0f110c54552b269ea0eadbec80',1,'Video']]],
  ['videoplayer_1',['VideoPlayer',['../d3/d7a/class_video_player.html#a00262511eb06de0b83092285cae693df',1,'VideoPlayer::VideoPlayer()=default'],['../d3/d7a/class_video_player.html#aa4f9c496d3eb0d90fc77163ed931c64f',1,'VideoPlayer::VideoPlayer(VideoPlayer &amp;vid)=delete']]],
  ['videoplayeradapter_2',['VideoPlayerAdapter',['../d6/dfa/class_video_player_adapter.html#a75ebf6260c88c062ba480d1b00fdfdcd',1,'VideoPlayerAdapter::VideoPlayerAdapter(VideoPlayer &amp;VidPlayer)'],['../d6/dfa/class_video_player_adapter.html#a008f2e0ef40a8c574360a3a864a302fe',1,'VideoPlayerAdapter::VideoPlayerAdapter(VideoPlayerAdapter &amp;vid)=delete']]],
  ['volldec_3',['VollDec',['../d5/d7a/class_i_player.html#a3464b3862e2fd97bdcd22aeb8a8bc463',1,'IPlayer::VollDec()'],['../d1/dc7/class_music_player_adapter.html#ab4e50d46fae1f2777799463e4d54f918',1,'MusicPlayerAdapter::VollDec()'],['../d6/dfa/class_video_player_adapter.html#a0ce233a7038b946b59dad9323d529bbe',1,'VideoPlayerAdapter::VollDec()']]],
  ['vollinc_4',['VollInc',['../d5/d7a/class_i_player.html#ade0462490905ceeab23f1b491911f49c',1,'IPlayer::VollInc()'],['../d1/dc7/class_music_player_adapter.html#ae06c332b9dbb68b1144447495c090fee',1,'MusicPlayerAdapter::VollInc()'],['../d6/dfa/class_video_player_adapter.html#ae4cf6c1f832af929d4088453017b55d6',1,'VideoPlayerAdapter::VollInc()']]]
];
