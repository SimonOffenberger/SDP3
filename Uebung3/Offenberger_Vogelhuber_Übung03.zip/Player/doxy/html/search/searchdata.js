var indexSectionsWithContent =
{
  0: "acdefgimnoprstvw~",
  1: "cimosv",
  2: "ceimostv",
  3: "acdfgimnoprstvw~",
  4: "cdem",
  5: "st",
  6: "e",
  7: "amw",
  8: "cow"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Macros"
};

