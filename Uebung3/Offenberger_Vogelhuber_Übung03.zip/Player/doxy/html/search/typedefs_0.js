var searchData=
[
  ['songcollection_0',['SongCollection',['../de/de6/_music_player_8hpp.html#a641635ca38161ab1482bba674cb7fd42',1,'MusicPlayer.hpp']]]
];
