var searchData=
[
  ['default_5fvolume_0',['DEFAULT_VOLUME',['../dd/de1/class_music_player.html#a6bdf40a5a0b5b89f8ce44835c8fdd1b3',1,'MusicPlayer::DEFAULT_VOLUME'],['../d3/d7a/class_video_player.html#a642a96d19cfcc8b35135dee47e195707',1,'VideoPlayer::DEFAULT_VOLUME']]]
];
