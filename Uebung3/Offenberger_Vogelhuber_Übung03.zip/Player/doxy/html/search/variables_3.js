var searchData=
[
  ['m_5fcurindex_0',['m_curIndex',['../d3/d7a/class_video_player.html#aac9dc422314a6e42e12e39705a8ae17d',1,'VideoPlayer']]],
  ['m_5fcurrentsongidx_1',['m_currentSongIdx',['../dd/de1/class_music_player.html#aed3047e0799e34d4f207803ae6373559',1,'MusicPlayer']]],
  ['m_5fduration_2',['m_duration',['../da/dc3/class_song.html#a4fed272352dee6bfbc0927e1f34c8fcc',1,'Song::m_duration'],['../d2/d47/class_video.html#aecd2e1ee7b7ef7493384b2cce414c2f3',1,'Video::m_duration']]],
  ['m_5fformat_3',['m_format',['../d2/d47/class_video.html#a8ea400101b2d6cc8be10d04a0ed9da8a',1,'Video']]],
  ['m_5fname_4',['m_name',['../da/dc3/class_song.html#a4dd7fc1d05e40d4512c079c8f76651d7',1,'Song']]],
  ['m_5fplayer_5',['m_player',['../d1/dc7/class_music_player_adapter.html#a0b9daea00381389803f3fb2fec9dba77',1,'MusicPlayerAdapter::m_player'],['../d6/dfa/class_video_player_adapter.html#a67733ff1012b9254eeab52de7499b4e7',1,'VideoPlayerAdapter::m_player']]],
  ['m_5fsongs_6',['m_songs',['../dd/de1/class_music_player.html#a119d15fa7ad0c43e73a30a3b2091b4f9',1,'MusicPlayer']]],
  ['m_5ftitle_7',['m_title',['../d2/d47/class_video.html#a9b39ce43417fed1f3da42d8c28ed5b4e',1,'Video']]],
  ['m_5fvideos_8',['m_Videos',['../d3/d7a/class_video_player.html#ad4c3cc18022c0a7fc3762d68a1450cca',1,'VideoPlayer']]],
  ['m_5fvolume_9',['m_volume',['../dd/de1/class_music_player.html#a8741c469dbb31a8df65b35a068b2116f',1,'MusicPlayer::m_volume'],['../d3/d7a/class_video_player.html#aa8153f648061bd1242460099e460e088',1,'VideoPlayer::m_volume']]],
  ['max_5fvolume_10',['MAX_VOLUME',['../dd/de1/class_music_player.html#a4a7b0482238a1137788f69ec5871891d',1,'MusicPlayer::MAX_VOLUME'],['../d3/d7a/class_video_player.html#ad08658b265b785891e7cb418d47df983',1,'VideoPlayer::MAX_VOLUME']]],
  ['min_5fvolume_11',['MIN_VOLUME',['../dd/de1/class_music_player.html#a9a3a4109af51f0d3781ba8d5b0609438',1,'MusicPlayer::MIN_VOLUME'],['../d3/d7a/class_video_player.html#a5fb4b012843cb7afa5a4b9c4ea6d764f',1,'VideoPlayer::MIN_VOLUME']]]
];
