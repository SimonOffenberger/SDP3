/*****************************************************************//**
 * \file   JavaSymbolFactory.hpp
 * \brief  A factory for creating java variables and types
 * \author Simon 
 * \date   Dezember 2025
 *********************************************************************/
#ifndef JAVA_SYMBOL_FACTORY_HPP
#define JAVA_SYMBOL_FACTORY_HPP

#include "ISymbolFactory.hpp"
#include "SingetonBase.hpp"

class JavaSymbolFactory :public ISymbolFactory, public SingletonBase<JavaSymbolFactory>
{
public:

	friend class SingletonBase<JavaSymbolFactory>;

	/**
	 * \brief Creates a java variable
	 *
	 * \param string of variables name
	 * \return unique pointer to variable
	 */
	virtual Variable::Uptr CreateVariable(const std::string& name) const override;

	/**
	 * \brief Creates a java type
	 *
	 * \param string of typename
	 * \return unique pointer to type
	 */
	virtual Type::Uptr CreateType(const std::string& name) const override;

	/**
	 * \brief Getter for file path of type file
	 *
	 * \return string of filePath
	 */
	virtual const std::string& GetTypeFileName() const override;

	/**
	 * \brief Getter for file path of variable file
	 *
	 * \return string of filePath
	 */
	virtual const std::string& GetVariableFileName() const override;

	// delete CopyCtor and Assign operator to prevent untestet behaviour
	JavaSymbolFactory(JavaSymbolFactory& fact) = delete;
	void operator=(JavaSymbolFactory fact) = delete;

protected:
private:
	JavaSymbolFactory() = default;
	const std::string m_TypeFileName = "JavaTypes.sym";
	const std::string m_VariableFileName = "JavaVars.sym";
};
#endif