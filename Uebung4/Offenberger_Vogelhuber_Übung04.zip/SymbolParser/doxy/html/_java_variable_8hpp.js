var _java_variable_8hpp =
[
    [ "JavaVariable", "class_java_variable.html", "class_java_variable" ]
];