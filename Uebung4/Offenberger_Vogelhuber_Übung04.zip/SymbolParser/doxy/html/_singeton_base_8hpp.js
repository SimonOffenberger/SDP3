var _singeton_base_8hpp =
[
    [ "SingletonBase< T >", "class_singleton_base.html", null ]
];