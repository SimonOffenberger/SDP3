var _type_8hpp =
[
    [ "Type", "class_type.html", "class_type" ]
];