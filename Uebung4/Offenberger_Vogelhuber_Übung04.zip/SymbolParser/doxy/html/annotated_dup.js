var annotated_dup =
[
    [ "pfc", "da/d46/namespacepfc.html", [
      [ "scn", "db/d8a/namespacepfc_1_1scn.html", [
        [ "details", "d3/dd4/namespacepfc_1_1scn_1_1details.html", [
          [ "symbol_kind", "d9/d81/structpfc_1_1scn_1_1details_1_1symbol__kind.html", "d9/d81/structpfc_1_1scn_1_1details_1_1symbol__kind" ]
        ] ],
        [ "exception", "de/dc6/structpfc_1_1scn_1_1exception.html", "de/dc6/structpfc_1_1scn_1_1exception" ]
      ] ],
      [ "scanner", "dc/d5f/classpfc_1_1scanner.html", "dc/d5f/classpfc_1_1scanner" ],
      [ "symbol", "d5/db8/structpfc_1_1symbol.html", "d5/db8/structpfc_1_1symbol" ]
    ] ],
    [ "Identifier", "d7/de7/class_identifier.html", "d7/de7/class_identifier" ],
    [ "IECSymbolFactory", "dc/d2c/class_i_e_c_symbol_factory.html", "dc/d2c/class_i_e_c_symbol_factory" ],
    [ "IECType", "d7/dc6/class_i_e_c_type.html", "d7/dc6/class_i_e_c_type" ],
    [ "IECVariable", "de/db6/class_i_e_c_variable.html", "de/db6/class_i_e_c_variable" ],
    [ "ISymbolFactory", "d0/d2f/class_i_symbol_factory.html", "d0/d2f/class_i_symbol_factory" ],
    [ "JavaSymbolFactory", "d9/dd2/class_java_symbol_factory.html", "d9/dd2/class_java_symbol_factory" ],
    [ "JavaType", "dd/db2/class_java_type.html", "dd/db2/class_java_type" ],
    [ "JavaVariable", "dc/d8d/class_java_variable.html", "dc/d8d/class_java_variable" ],
    [ "Object", "d8/d83/class_object.html", "d8/d83/class_object" ],
    [ "SingletonBase", "db/da7/class_singleton_base.html", "db/da7/class_singleton_base" ],
    [ "SymbolParser", "d4/d5b/class_symbol_parser.html", "d4/d5b/class_symbol_parser" ],
    [ "Type", "d8/df6/class_type.html", "d8/df6/class_type" ],
    [ "Variable", "d2/d3c/class_variable.html", "d2/d3c/class_variable" ]
];