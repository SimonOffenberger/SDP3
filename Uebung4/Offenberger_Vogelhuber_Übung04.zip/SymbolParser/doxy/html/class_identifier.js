var class_identifier =
[
    [ "GetName", "class_identifier.html#aa8a1bf4d9bb4dc2cd46321ca95b5bd39", null ],
    [ "SetName", "class_identifier.html#aed6f8e102194f303f5c9a2f9d0f5e143", null ]
];