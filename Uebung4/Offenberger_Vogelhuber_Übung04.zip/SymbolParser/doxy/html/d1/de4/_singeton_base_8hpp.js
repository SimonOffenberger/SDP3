var _singeton_base_8hpp =
[
    [ "SingletonBase< T >", "db/da7/class_singleton_base.html", "db/da7/class_singleton_base" ],
    [ "SingletonBase< T >::mInstance", "d1/de4/_singeton_base_8hpp.html#aa29ac693a90a5bd0584c0114c6a24fe1", null ]
];