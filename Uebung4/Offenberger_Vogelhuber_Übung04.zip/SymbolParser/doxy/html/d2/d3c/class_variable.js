var class_variable =
[
    [ "Uptr", "d2/d3c/class_variable.html#a4016f47db53ca616aa468fa78358d8bc", null ],
    [ "Variable", "d2/d3c/class_variable.html#aae9a2273769092961aee44f8cd87bf85", null ],
    [ "Variable", "d2/d3c/class_variable.html#a964aafa0ae98b0052666399f0dd84270", null ],
    [ "GetSaveLine", "d2/d3c/class_variable.html#a33e28b806105ba2a5987fc0144f350b2", null ],
    [ "GetTypeName", "d2/d3c/class_variable.html#a173120dea6866490cab4ee809c42fb8b", null ],
    [ "LoadTypeName", "d2/d3c/class_variable.html#ae3d2d6ff4b212351bdb34ce884077da9", null ],
    [ "LoadVarName", "d2/d3c/class_variable.html#a0c6c2bb537e72793944c047877c4881a", null ],
    [ "SetType", "d2/d3c/class_variable.html#af08433f0bc55c378d4272ebd0a2d018c", null ],
    [ "m_type", "d2/d3c/class_variable.html#acf1acab1e5c43e7aa9bc238df6cddfe8", null ]
];