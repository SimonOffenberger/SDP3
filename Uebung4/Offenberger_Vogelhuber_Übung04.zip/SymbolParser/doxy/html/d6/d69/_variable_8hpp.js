var _variable_8hpp =
[
    [ "Variable", "d2/d3c/class_variable.html", "d2/d3c/class_variable" ]
];