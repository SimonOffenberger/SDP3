var _java_type_8hpp =
[
    [ "JavaType", "dd/db2/class_java_type.html", "dd/db2/class_java_type" ]
];