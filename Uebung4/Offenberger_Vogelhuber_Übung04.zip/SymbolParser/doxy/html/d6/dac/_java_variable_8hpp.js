var _java_variable_8hpp =
[
    [ "JavaVariable", "dc/d8d/class_java_variable.html", "dc/d8d/class_java_variable" ]
];