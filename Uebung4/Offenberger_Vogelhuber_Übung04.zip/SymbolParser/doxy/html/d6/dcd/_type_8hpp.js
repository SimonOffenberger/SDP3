var _type_8hpp =
[
    [ "Type", "d8/df6/class_type.html", "d8/df6/class_type" ]
];