var class_identifier =
[
    [ "Identifier", "d7/de7/class_identifier.html#aabb931c2d796e40b79d0adc5ac356c1a", null ],
    [ "Identifier", "d7/de7/class_identifier.html#ac57bff164e51696a150997c12fc8a9a1", null ],
    [ "GetName", "d7/de7/class_identifier.html#a97633c8c910e38ca3485f517486a85bb", null ],
    [ "SetName", "d7/de7/class_identifier.html#aed6f8e102194f303f5c9a2f9d0f5e143", null ],
    [ "m_name", "d7/de7/class_identifier.html#a0e69b0efd59f3799445991ec59636ee0", null ]
];