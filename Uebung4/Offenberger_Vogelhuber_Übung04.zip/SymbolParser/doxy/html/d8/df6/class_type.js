var class_type =
[
    [ "Sptr", "d8/df6/class_type.html#abc73d10e616d88a88db110754967d06d", null ],
    [ "Uptr", "d8/df6/class_type.html#ab13cb49bd8ebbbae849a537cb0afd13e", null ],
    [ "Type", "d8/df6/class_type.html#ac8674a7f7581fdc535376adf12437bc6", null ],
    [ "Type", "d8/df6/class_type.html#a571cd982de307ade28ef73435cf01bf5", null ],
    [ "GetSaveLine", "d8/df6/class_type.html#a36c1232e2bdd82f34738e11741a966c7", null ],
    [ "LoadTypeName", "d8/df6/class_type.html#aedb7ca31d7c944280c2f2dcdb3ccadb7", null ]
];