var namespacepfc_1_1scn =
[
    [ "details", "d3/dd4/namespacepfc_1_1scn_1_1details.html", "d3/dd4/namespacepfc_1_1scn_1_1details" ],
    [ "exception", "de/dc6/structpfc_1_1scn_1_1exception.html", "de/dc6/structpfc_1_1scn_1_1exception" ]
];