var class_java_variable =
[
    [ "JavaVariable", "dc/d8d/class_java_variable.html#abf2932300e7bb5e43268c72d25159953", null ],
    [ "JavaVariable", "dc/d8d/class_java_variable.html#aec6255fe49fe43d22d2b27c6457635d7", null ],
    [ "GetSaveLine", "dc/d8d/class_java_variable.html#a5b1b3d1ae80a53025c8f686e171299be", null ],
    [ "LoadTypeName", "dc/d8d/class_java_variable.html#a9d11ecce85e622cc138f833a91478b1f", null ],
    [ "LoadVarName", "dc/d8d/class_java_variable.html#ab477be817beafd23dfb7c5fefdaffd18", null ]
];