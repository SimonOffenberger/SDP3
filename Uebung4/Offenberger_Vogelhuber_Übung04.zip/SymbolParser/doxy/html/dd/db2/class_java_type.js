var class_java_type =
[
    [ "JavaType", "dd/db2/class_java_type.html#a7e700e07105423070955d86a4f181df8", null ],
    [ "JavaType", "dd/db2/class_java_type.html#afa19a9bd2221fa3f5c50201195648b86", null ],
    [ "GetSaveLine", "dd/db2/class_java_type.html#aa83ca6a2956af8123d7883700b2d21bb", null ],
    [ "LoadTypeName", "dd/db2/class_java_type.html#ad19c312c3815b7835fe29e4508e7cf81", null ]
];