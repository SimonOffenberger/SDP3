var searchData=
[
  ['type_0',['Type',['../d8/df6/class_type.html',1,'']]]
];
