var searchData=
[
  ['variable_0',['Variable',['../d2/d3c/class_variable.html',1,'']]]
];
