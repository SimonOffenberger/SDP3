var searchData=
[
  ['pfc_5fscanner_5fversion_0',['PFC_SCANNER_VERSION',['../db/d62/scanner_8h.html#a14b0aa45551fe8ea7b88b4484d90767e',1,'scanner.h']]]
];
