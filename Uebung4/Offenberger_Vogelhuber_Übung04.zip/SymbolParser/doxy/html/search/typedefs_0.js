var searchData=
[
  ['sptr_0',['Sptr',['../d8/df6/class_type.html#abc73d10e616d88a88db110754967d06d',1,'Type']]]
];
