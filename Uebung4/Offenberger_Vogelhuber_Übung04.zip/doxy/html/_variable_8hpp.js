var _variable_8hpp =
[
    [ "Variable", "class_variable.html", "class_variable" ]
];