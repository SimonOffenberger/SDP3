var annotated_dup =
[
    [ "pfc", null, [
      [ "scn", null, [
        [ "details", null, [
          [ "symbol_kind", "structpfc_1_1scn_1_1details_1_1symbol__kind.html", null ]
        ] ],
        [ "exception", "structpfc_1_1scn_1_1exception.html", null ]
      ] ],
      [ "scanner", "classpfc_1_1scanner.html", null ],
      [ "symbol", "structpfc_1_1symbol.html", null ]
    ] ],
    [ "Identifier", "class_identifier.html", "class_identifier" ],
    [ "IECSymbolFactory", "class_i_e_c_symbol_factory.html", "class_i_e_c_symbol_factory" ],
    [ "IECType", "class_i_e_c_type.html", "class_i_e_c_type" ],
    [ "IECVariable", "class_i_e_c_variable.html", "class_i_e_c_variable" ],
    [ "ISymbolFactory", "class_i_symbol_factory.html", "class_i_symbol_factory" ],
    [ "JavaSymbolFactory", "class_java_symbol_factory.html", "class_java_symbol_factory" ],
    [ "JavaType", "class_java_type.html", "class_java_type" ],
    [ "JavaVariable", "class_java_variable.html", "class_java_variable" ],
    [ "Object", "class_object.html", null ],
    [ "SingletonBase", "class_singleton_base.html", null ],
    [ "SymbolParser", "class_symbol_parser.html", "class_symbol_parser" ],
    [ "Type", "class_type.html", "class_type" ],
    [ "Variable", "class_variable.html", "class_variable" ]
];