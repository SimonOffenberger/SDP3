var class_java_variable =
[
    [ "GetSaveLine", "class_java_variable.html#a5b1b3d1ae80a53025c8f686e171299be", null ],
    [ "LoadTypeName", "class_java_variable.html#a9d11ecce85e622cc138f833a91478b1f", null ],
    [ "LoadVarName", "class_java_variable.html#ab477be817beafd23dfb7c5fefdaffd18", null ]
];