var class_type =
[
    [ "Sptr", "class_type.html#abc73d10e616d88a88db110754967d06d", null ],
    [ "Uptr", "class_type.html#ab13cb49bd8ebbbae849a537cb0afd13e", null ],
    [ "GetSaveLine", "class_type.html#a36c1232e2bdd82f34738e11741a966c7", null ],
    [ "LoadTypeName", "class_type.html#aedb7ca31d7c944280c2f2dcdb3ccadb7", null ]
];