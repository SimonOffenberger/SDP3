var class_variable =
[
    [ "Uptr", "class_variable.html#a4016f47db53ca616aa468fa78358d8bc", null ],
    [ "GetSaveLine", "class_variable.html#a33e28b806105ba2a5987fc0144f350b2", null ],
    [ "GetTypeName", "class_variable.html#a173120dea6866490cab4ee809c42fb8b", null ],
    [ "LoadTypeName", "class_variable.html#ae3d2d6ff4b212351bdb34ce884077da9", null ],
    [ "LoadVarName", "class_variable.html#a0c6c2bb537e72793944c047877c4881a", null ],
    [ "SetType", "class_variable.html#af08433f0bc55c378d4272ebd0a2d018c", null ]
];