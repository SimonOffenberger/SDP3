var dir_b9cc87c962421726742cee2ced4952ed =
[
    [ "Übung", "dir_7b24da6d519f781230c569871c2cfb81.html", "dir_7b24da6d519f781230c569871c2cfb81" ]
];