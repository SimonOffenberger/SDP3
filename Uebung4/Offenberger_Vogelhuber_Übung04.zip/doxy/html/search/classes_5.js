var searchData=
[
  ['type_0',['Type',['../class_type.html',1,'']]]
];
