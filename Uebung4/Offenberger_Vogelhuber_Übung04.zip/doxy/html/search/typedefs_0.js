var searchData=
[
  ['sptr_0',['Sptr',['../class_type.html#abc73d10e616d88a88db110754967d06d',1,'Type']]]
];
