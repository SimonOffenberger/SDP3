var class_i_display =
[
    [ "Sptr", "class_i_display.html#a7583b70df84ded578818af2693675d05", null ],
    [ "~IDisplay", "class_i_display.html#a3f639a4bdb0ab42276fee151c99ea2d8", null ],
    [ "Update", "class_i_display.html#a1ee3bc30b6b87fed05a9d3eea659deb0", null ]
];