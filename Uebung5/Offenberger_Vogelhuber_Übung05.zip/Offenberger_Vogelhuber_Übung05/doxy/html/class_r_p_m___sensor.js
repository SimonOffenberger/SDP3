var class_r_p_m___sensor =
[
    [ "Sptr", "class_r_p_m___sensor.html#a479b0f10fbe3b3ea0cdee630dc8a0e8a", null ],
    [ "RPM_Sensor", "class_r_p_m___sensor.html#a909f9ecd2323a98a35abbc7fab2d0cef", null ],
    [ "~RPM_Sensor", "class_r_p_m___sensor.html#a15207cf8078a880997b4dfdf468f1127", null ],
    [ "GetRevolutions", "class_r_p_m___sensor.html#a06b12c33d06000b135857704e3a4358c", null ]
];