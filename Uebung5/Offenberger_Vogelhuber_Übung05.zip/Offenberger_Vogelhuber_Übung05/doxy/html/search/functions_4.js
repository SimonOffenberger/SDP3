var searchData=
[
  ['meter_0',['Meter',['../class_meter.html#a8bb256cbf804dadbd93cf6b66fd5fccb',1,'Meter::Meter(WindowsDisplay::SPtr display)'],['../class_meter.html#a83d56a4b3110cc8f0693508d61e39d88',1,'Meter::Meter()=default']]]
];
