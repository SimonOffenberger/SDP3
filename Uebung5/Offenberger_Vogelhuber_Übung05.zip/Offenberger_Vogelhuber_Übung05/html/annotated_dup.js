var annotated_dup =
[
    [ "AnalogDisplay", "class_analog_display.html", null ],
    [ "Car", "class_car.html", "class_car" ],
    [ "DataPacket", "struct_data_packet.html", null ],
    [ "DigitalDisplay", "class_digital_display.html", null ],
    [ "IDisplay", "class_i_display.html", "class_i_display" ],
    [ "Meter", "class_meter.html", "class_meter" ],
    [ "Object", "class_object.html", null ],
    [ "Odometer", "class_odometer.html", "class_odometer" ],
    [ "RPM_Sensor", "class_r_p_m___sensor.html", "class_r_p_m___sensor" ],
    [ "Tachometer", "class_tachometer.html", "class_tachometer" ],
    [ "Vehicle", "class_vehicle.html", "class_vehicle" ],
    [ "WindowsDisplay", "class_windows_display.html", null ]
];