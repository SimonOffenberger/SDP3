var class_car =
[
    [ "Sptr", "class_car.html#a08d10a5e2ed861538483273ae5d75ca5", null ],
    [ "Wptr", "class_car.html#ae1b7279e76abac6f77b08006e4cfdfb0", null ],
    [ "Car", "class_car.html#a78c97b184677d7ff94d232884542cfae", null ],
    [ "GetCurrentSpeed", "class_car.html#a6f0193b94c28ec0ef2a887445a37e5d1", null ],
    [ "Process", "class_car.html#a3ac746b22d54e8e1fd425678a856f85f", null ]
];