var hierarchy =
[
    [ "DataPacket", "struct_data_packet.html", null ],
    [ "IDisplay", "class_i_display.html", [
      [ "Meter", "class_meter.html", [
        [ "Odometer", "class_odometer.html", null ],
        [ "Tachometer", "class_tachometer.html", null ]
      ] ]
    ] ],
    [ "Object", "class_object.html", [
      [ "Meter", "class_meter.html", null ],
      [ "RPM_Sensor", "class_r_p_m___sensor.html", null ],
      [ "Vehicle", "class_vehicle.html", [
        [ "Car", "class_car.html", null ]
      ] ],
      [ "WindowsDisplay", "class_windows_display.html", [
        [ "AnalogDisplay", "class_analog_display.html", null ],
        [ "DigitalDisplay", "class_digital_display.html", null ]
      ] ]
    ] ]
];