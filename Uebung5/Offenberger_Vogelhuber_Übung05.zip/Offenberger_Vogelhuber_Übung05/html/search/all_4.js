var searchData=
[
  ['getcurrentspeed_0',['GetCurrentSpeed',['../class_car.html#a6f0193b94c28ec0ef2a887445a37e5d1',1,'Car']]],
  ['getmilage_1',['GetMilage',['../class_odometer.html#ae0bc1484fd0a506da2a2805cd3b0aa1a',1,'Odometer']]],
  ['getrevolutions_2',['GetRevolutions',['../class_r_p_m___sensor.html#a06b12c33d06000b135857704e3a4358c',1,'RPM_Sensor']]]
];
