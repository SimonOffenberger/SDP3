var searchData=
[
  ['tachometer_0',['Tachometer',['../class_tachometer.html#ab8f0aabb9e3bbf4b01b1d4b9a28b01a0',1,'Tachometer::Tachometer(Car::Sptr car, WindowsDisplay::SPtr display)'],['../class_tachometer.html#a8122f8b149199e7f1c9ec84e57af1523',1,'Tachometer::Tachometer(Car::Sptr car)']]]
];
