/*****************************************************************//**
 * \file Folder.hpp
 * \brief Folder class representing a folder in the filesystem
 *
 * \author Simon
 * \date   November 2025
 *********************************************************************/
#ifndef FOLDER_HPP
#define FOLDER_HPP

#include "IFolder.hpp"
#include "IVisitor.hpp"
#include "FSObject.hpp"

#include <memory>
#include <vector>

class Folder : public IFolder, public FSObject, public std::enable_shared_from_this<Folder>
{
public:

	// Smart pointer types
	using Uptr = std::unique_ptr<Folder>;
	using Sptr = std::shared_ptr<Folder>;
	using Wptr = std::weak_ptr<Folder>;
	using Cont = std::vector<FSObj_Sptr>;

	/** \brief Construct a folder with a name
	 * \param name Name of the folder
	 */
	Folder(std::string_view name) : FSObject(name) {}

	/** \brief Add a child FSObject to this folder
	 * \param fsobj Shared pointer to the child
	 */
	virtual void Add(FSObj_Sptr fsobj);

	/** \brief Get child by index
	 * \param idx Index (by value is faster than by reference)
	 * \return Shared pointer to child or nullptr
	 */
	virtual FSObj_Sptr GetChild(const size_t idx) const override;

	/** \brief Remove a child from the folder
	 * \param fsobj Child to remove
	 */
	virtual void Remove(FSObj_Sptr fsobj);

	/** \brief Cast this FSObject to a folder interface
	 * \return Shared pointer to IFolder
	 */
	virtual std::shared_ptr<const IFolder> AsFolder() const override;

	/** \brief Cast this FSObject to a folder interface
	 * \return Shared pointer to IFolder
	 */
	virtual IFolder::Sptr AsFolder() override;

	/** \brief Accept a visitor and propagate to children
	 * \param visit Visitor to accept
	 */
	virtual void Accept(IVisitor& visit) override;

	/** \brief Clones it self as a new
	*  \return Shared pointer to the cloned FSObject
	*/
	virtual FSObj_Sptr Clone() const override;

	/** \brief Assignment operator for Folder
	 * This makes a deep copy of the folder and its children.
	 * \param fold Folder to copy from
	 */
	void operator=(const Folder& fold);

protected:
	/**
	 * \brief Copy Constructor of a Folder .
	 * This makes a deep copy of the folder and its children.
	 * This is protected to prevent direct usage, use Clone() instead
	 * This is done because the parent pointer needs to be set correctly, and this 
	 * cannot be done in the copy constructor directly.
	 * \param fold
	 */
	Folder(const Folder& fold);
	
	// DTOR is defaulted because no special action is needed!

private:
	Folder::Cont m_Children;
};

#endif
