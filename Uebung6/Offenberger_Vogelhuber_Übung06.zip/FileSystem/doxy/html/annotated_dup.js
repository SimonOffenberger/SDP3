var annotated_dup =
[
    [ "DumpVisitor", "class_dump_visitor.html", "class_dump_visitor" ],
    [ "File", "class_file.html", "class_file" ],
    [ "FileSystem", "class_file_system.html", "class_file_system" ],
    [ "FilterFileVisitor", "class_filter_file_visitor.html", "class_filter_file_visitor" ],
    [ "FilterLinkVisitor", "class_filter_link_visitor.html", "class_filter_link_visitor" ],
    [ "FilterVisitor", "class_filter_visitor.html", "class_filter_visitor" ],
    [ "Folder", "class_folder.html", "class_folder" ],
    [ "FSObject", "class_f_s_object.html", "class_f_s_object" ],
    [ "FSObjectFactory", "class_f_s_object_factory.html", "class_f_s_object_factory" ],
    [ "IFolder", "class_i_folder.html", "class_i_folder" ],
    [ "ILink", "class_i_link.html", "class_i_link" ],
    [ "IVisitor", "class_i_visitor.html", "class_i_visitor" ],
    [ "Link", "class_link.html", "class_link" ],
    [ "Object", "class_object.html", "class_object" ]
];