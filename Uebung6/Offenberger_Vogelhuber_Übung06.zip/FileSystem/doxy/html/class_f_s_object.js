var class_f_s_object =
[
    [ "FSObject", "class_f_s_object.html#a8fb4b0e0ec2d80b7d785bf0d1bfa6bb7", null ],
    [ "Accept", "class_f_s_object.html#addad51e0e85a75e3de9453410ce9e5d1", null ],
    [ "AsFolder", "class_f_s_object.html#af1185a4888f4e85c5e1b2b60391f3f18", null ],
    [ "AsFolder", "class_f_s_object.html#a532e66249339dfc3d274058c5b6c2eef", null ],
    [ "AsLink", "class_f_s_object.html#aa38a416a3798a9746d70aa5fcd3a2997", null ],
    [ "Clone", "class_f_s_object.html#abfbed5ad342c9aa829aae1fab1c7e52d", null ],
    [ "GetName", "class_f_s_object.html#a45a3a507d09c23729f2fd9dd4cf7c296", null ],
    [ "GetParent", "class_f_s_object.html#ab0dbe6305a976a871fde1b7a364f70e1", null ],
    [ "SetName", "class_f_s_object.html#a07e7d325c0b1e0051d1382f9fe5439c6", null ],
    [ "SetParent", "class_f_s_object.html#a1ea015d35ad689380d48eae748b0a061", null ]
];