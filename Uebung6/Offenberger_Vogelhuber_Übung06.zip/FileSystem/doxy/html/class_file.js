var class_file =
[
    [ "File", "class_file.html#aa557e73cacd78b7ca8845abcb61be01a", null ],
    [ "Accept", "class_file.html#a030e2d798a7bc915bb17ff0d38ed259e", null ],
    [ "Clone", "class_file.html#ab843e7c6ab60f7eae08776cd62340884", null ],
    [ "GetSize", "class_file.html#ad80e11267b1ad8448e228b5e02d34f4f", null ],
    [ "Write", "class_file.html#af4d87c0bf438905ab55d9a2ba8834ec7", null ]
];