var class_folder =
[
    [ "Folder", "class_folder.html#afc294d1810c0f9ef39f2611aee89fbca", null ],
    [ "Folder", "class_folder.html#a575323318b3a7a6fabab366c725a752c", null ],
    [ "Accept", "class_folder.html#a391cdc29a44d54bbcd8eab18e30b5072", null ],
    [ "Add", "class_folder.html#af078cbf3081a93704e74d4b62d38e879", null ],
    [ "AsFolder", "class_folder.html#a6dbaf6d6b1e9dba5d67a1caa6e886497", null ],
    [ "AsFolder", "class_folder.html#a9609d477f80f43168627eafef20bab41", null ],
    [ "Clone", "class_folder.html#af8e5884f0c7f3739fdad6f12f4a10f85", null ],
    [ "GetChild", "class_folder.html#a110d0d3c62c4d8b11882579f9489ea5f", null ],
    [ "operator=", "class_folder.html#a8c2982f59d222745e39784b069a12710", null ],
    [ "Remove", "class_folder.html#a39e18ab032ae68555f8b5ff33a008db5", null ]
];