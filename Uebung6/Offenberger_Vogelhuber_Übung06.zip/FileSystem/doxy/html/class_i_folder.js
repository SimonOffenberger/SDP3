var class_i_folder =
[
    [ "~IFolder", "class_i_folder.html#a19628dd66894d66ed6b215daad2bf8be", null ],
    [ "Add", "class_i_folder.html#a3655ec40368361feb40223e301c9bb49", null ],
    [ "GetChild", "class_i_folder.html#a8d294bd6dc29c19d2ba0717c55aa0035", null ],
    [ "Remove", "class_i_folder.html#ad8a83a5ce49f9c254976e7bf829ad5a5", null ]
];