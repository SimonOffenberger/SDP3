var class_link =
[
    [ "Link", "class_link.html#a72a5b9bf12806c74da79742591163fe4", null ],
    [ "Accept", "class_link.html#afe8e0bc3d75284a5eaedc5226410b703", null ],
    [ "AsLink", "class_link.html#ac0d5cdb12109417deb8ff952ec5a5a0a", null ],
    [ "Clone", "class_link.html#ae05335bb301c16c76c180022cf1f0668", null ],
    [ "GetReferncedFSObject", "class_link.html#a0cc9ab65b667500729b6e5b8970b1db8", null ]
];