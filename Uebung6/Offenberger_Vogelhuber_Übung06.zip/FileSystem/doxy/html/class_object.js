var class_object =
[
    [ "Object", "class_object.html#afe9eeddd7068a37f62d3276a2fb49864", null ],
    [ "~Object", "class_object.html#aa3e791419d84c4c346ef9499513b8e00", null ]
];