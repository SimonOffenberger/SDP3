var searchData=
[
  ['remove_0',['Remove',['../class_folder.html#a39e18ab032ae68555f8b5ff33a008db5',1,'Folder::Remove()'],['../class_i_folder.html#ad8a83a5ce49f9c254976e7bf829ad5a5',1,'IFolder::Remove()']]],
  ['returnroot_1',['ReturnRoot',['../class_file_system.html#a324ac393cc165e83b7e5d81bad6194f4',1,'FileSystem']]]
];
