var searchData=
[
  ['object_0',['Object',['../class_object.html#afe9eeddd7068a37f62d3276a2fb49864',1,'Object']]],
  ['operator_3d_1',['operator=',['../class_folder.html#a8c2982f59d222745e39784b069a12710',1,'Folder']]]
];
