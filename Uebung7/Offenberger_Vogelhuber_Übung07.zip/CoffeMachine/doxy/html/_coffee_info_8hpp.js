var _coffee_info_8hpp =
[
    [ "CoffeeInfo", "class_coffee_info.html", null ]
];