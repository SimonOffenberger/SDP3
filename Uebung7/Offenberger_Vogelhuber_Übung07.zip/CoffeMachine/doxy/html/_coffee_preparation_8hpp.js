var _coffee_preparation_8hpp =
[
    [ "CoffeePreparation", "class_coffee_preparation.html", "class_coffee_preparation" ]
];