var _decaff_8hpp =
[
    [ "Decaff", "class_decaff.html", "class_decaff" ]
];