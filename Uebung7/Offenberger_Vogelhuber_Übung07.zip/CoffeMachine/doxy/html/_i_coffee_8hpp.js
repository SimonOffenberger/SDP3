var _i_coffee_8hpp =
[
    [ "ICoffee", "class_i_coffee.html", "class_i_coffee" ]
];