var _ingredient_8hpp =
[
    [ "Ingredient", "class_ingredient.html", "class_ingredient" ]
];