var _soja_milk_8hpp =
[
    [ "SojaMilk", "class_soja_milk.html", "class_soja_milk" ]
];