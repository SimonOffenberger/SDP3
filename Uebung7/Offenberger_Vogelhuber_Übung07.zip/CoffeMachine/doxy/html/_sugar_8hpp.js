var _sugar_8hpp =
[
    [ "Sugar", "class_sugar.html", "class_sugar" ]
];