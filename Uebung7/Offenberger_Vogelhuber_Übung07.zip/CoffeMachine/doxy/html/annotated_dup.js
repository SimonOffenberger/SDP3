var annotated_dup =
[
    [ "CoffeeInfo", "class_coffee_info.html", null ],
    [ "CoffeePreparation", "class_coffee_preparation.html", "class_coffee_preparation" ],
    [ "Cream", "class_cream.html", "class_cream" ],
    [ "Decaff", "class_decaff.html", "class_decaff" ],
    [ "Espresso", "class_espresso.html", "class_espresso" ],
    [ "ExtendedOne", "class_extended_one.html", "class_extended_one" ],
    [ "ICoffee", "class_i_coffee.html", "class_i_coffee" ],
    [ "Ingredient", "class_ingredient.html", "class_ingredient" ],
    [ "Milk", "class_milk.html", "class_milk" ],
    [ "Mocha", "class_mocha.html", "class_mocha" ],
    [ "Object", "class_object.html", "class_object" ],
    [ "SojaMilk", "class_soja_milk.html", "class_soja_milk" ],
    [ "Sugar", "class_sugar.html", "class_sugar" ]
];