var class_coffee_preparation =
[
    [ "Display", "class_coffee_preparation.html#af4d717ed90babf4598c1f29e34186d10", null ],
    [ "Finished", "class_coffee_preparation.html#a1199e228cac3095001f4dd85cb9b7819", null ],
    [ "Prepare", "class_coffee_preparation.html#a0478621b4818c8b8250c23bbda5bce46", null ]
];