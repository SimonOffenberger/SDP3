var class_cream =
[
    [ "Cream", "class_cream.html#a61cdfe2fffc52229a2d84aaaceaf5bd8", null ],
    [ "GetCost", "class_cream.html#ae529c66578036034d791eeb995b82cf5", null ],
    [ "GetDescription", "class_cream.html#a8a2abf5c55f45715a2a5371dc6bbcb31", null ]
];