var class_decaff =
[
    [ "GetCost", "class_decaff.html#aee417b05cdc47f98570d7ac6fd39f8c9", null ],
    [ "GetDescription", "class_decaff.html#a4b155c98b8e2d896d732f2970b72c4a1", null ]
];