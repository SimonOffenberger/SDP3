var class_espresso =
[
    [ "GetCost", "class_espresso.html#a121de387814f4bf006bcb827cf594aa0", null ],
    [ "GetDescription", "class_espresso.html#a1f8c98a1fbc0b97793ab0880cab4d022", null ]
];