var class_extended_one =
[
    [ "GetCost", "class_extended_one.html#a9e175ccb4fde122bb83a7e74b9c972c9", null ],
    [ "GetDescription", "class_extended_one.html#a7a0ec19b2953ed58e6197be507d7707c", null ]
];