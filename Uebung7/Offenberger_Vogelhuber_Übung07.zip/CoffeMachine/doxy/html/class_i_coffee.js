var class_i_coffee =
[
    [ "GetCost", "class_i_coffee.html#a848868c04c28b49f92315295bce95622", null ],
    [ "GetDescription", "class_i_coffee.html#acc7ef38e27555ad1e9531388ca2193be", null ]
];