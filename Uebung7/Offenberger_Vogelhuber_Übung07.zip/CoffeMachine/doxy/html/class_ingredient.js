var class_ingredient =
[
    [ "Ingredient", "class_ingredient.html#ae0fcedbe4c59b0d061f806f7ac2725eb", null ],
    [ "GetCost", "class_ingredient.html#a977689579eeebe9cb8bbd18bd081197b", null ],
    [ "GetDescription", "class_ingredient.html#a570cb83e50626e3cd3b651add4ed6c34", null ]
];