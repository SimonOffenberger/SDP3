var class_milk =
[
    [ "Milk", "class_milk.html#a24aeb8ae6471036672ea0515ad81fe84", null ],
    [ "GetCost", "class_milk.html#a1d328d9df6a3ac2a1cb105cfcb72a120", null ],
    [ "GetDescription", "class_milk.html#ab0aec5e77d72c15a298e1b8b7967f3e7", null ]
];