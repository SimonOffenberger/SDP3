var class_soja_milk =
[
    [ "SojaMilk", "class_soja_milk.html#a0d4729f05a2a8652b2a3dbed87896072", null ],
    [ "GetCost", "class_soja_milk.html#aaf576ea046358ae7e5f6960041edb638", null ],
    [ "GetDescription", "class_soja_milk.html#a57e47ef3da6df6fec2591da297fc5830", null ]
];