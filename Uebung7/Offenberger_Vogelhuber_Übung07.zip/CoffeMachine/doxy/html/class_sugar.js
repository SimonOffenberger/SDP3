var class_sugar =
[
    [ "Sugar", "class_sugar.html#a46cf185acb734bac418c866be01e06b8", null ],
    [ "GetCost", "class_sugar.html#acf07a12ef101c84fe0b7990832ac1003", null ],
    [ "GetDescription", "class_sugar.html#aac9193a32f6662d0c6e707f9663705d8", null ]
];