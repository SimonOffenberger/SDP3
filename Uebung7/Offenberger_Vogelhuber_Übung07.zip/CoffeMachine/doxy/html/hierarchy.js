var hierarchy =
[
    [ "CoffeePreparation", "class_coffee_preparation.html", null ],
    [ "ICoffee", "class_i_coffee.html", [
      [ "Decaff", "class_decaff.html", null ],
      [ "Espresso", "class_espresso.html", null ],
      [ "ExtendedOne", "class_extended_one.html", null ],
      [ "Ingredient", "class_ingredient.html", [
        [ "Cream", "class_cream.html", null ],
        [ "Milk", "class_milk.html", null ],
        [ "SojaMilk", "class_soja_milk.html", null ],
        [ "Sugar", "class_sugar.html", null ]
      ] ],
      [ "Mocha", "class_mocha.html", null ]
    ] ],
    [ "Object", "class_object.html", [
      [ "CoffeeInfo", "class_coffee_info.html", null ],
      [ "Decaff", "class_decaff.html", null ],
      [ "Espresso", "class_espresso.html", null ],
      [ "ExtendedOne", "class_extended_one.html", null ],
      [ "Ingredient", "class_ingredient.html", null ],
      [ "Mocha", "class_mocha.html", null ]
    ] ]
];