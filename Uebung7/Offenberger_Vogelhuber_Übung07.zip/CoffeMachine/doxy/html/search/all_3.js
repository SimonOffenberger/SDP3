var searchData=
[
  ['finished_0',['Finished',['../class_coffee_preparation.html#a1199e228cac3095001f4dd85cb9b7819',1,'CoffeePreparation']]]
];
