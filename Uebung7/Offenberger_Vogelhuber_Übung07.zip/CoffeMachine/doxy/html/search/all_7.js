var searchData=
[
  ['object_0',['Object',['../class_object.html',1,'Object'],['../class_object.html#afe9eeddd7068a37f62d3276a2fb49864',1,'Object::Object()']]],
  ['object_2eh_1',['Object.h',['../_object_8h.html',1,'']]]
];
