var searchData=
[
  ['prepare_0',['Prepare',['../class_coffee_preparation.html#a0478621b4818c8b8250c23bbda5bce46',1,'CoffeePreparation']]]
];
