var searchData=
[
  ['decaff_0',['Decaff',['../class_decaff.html',1,'']]]
];
