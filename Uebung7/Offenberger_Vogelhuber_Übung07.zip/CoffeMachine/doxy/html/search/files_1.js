var searchData=
[
  ['decaff_2ecpp_0',['Decaff.cpp',['../_decaff_8cpp.html',1,'']]],
  ['decaff_2ehpp_1',['Decaff.hpp',['../_decaff_8hpp.html',1,'']]]
];
