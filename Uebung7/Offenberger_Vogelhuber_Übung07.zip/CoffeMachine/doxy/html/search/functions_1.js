var searchData=
[
  ['display_0',['Display',['../class_coffee_preparation.html#af4d717ed90babf4598c1f29e34186d10',1,'CoffeePreparation']]]
];
