var searchData=
[
  ['ingredient_0',['Ingredient',['../class_ingredient.html#ae0fcedbe4c59b0d061f806f7ac2725eb',1,'Ingredient']]]
];
