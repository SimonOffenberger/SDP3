var searchData=
[
  ['sojamilk_0',['SojaMilk',['../class_soja_milk.html#a0d4729f05a2a8652b2a3dbed87896072',1,'SojaMilk']]],
  ['sugar_1',['Sugar',['../class_sugar.html#a46cf185acb734bac418c866be01e06b8',1,'Sugar']]]
];
